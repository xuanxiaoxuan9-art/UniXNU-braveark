# AGENTS.md — 接手本工作区的强制规则

本文件是给**任何接手本工作区的 AI / 协作者**的入口约束。开始工作前必须读完本文，
并按 §1 的顺序读对应文档。**违反 §2 / §5 的行为视为错误，不是风格问题。**

---

## 0. 这是什么工作区

在**小米平板 7 Pro（代号 `peridot`，SM8635，骁龙 8s Gen 3）**上运行 **UniXNU + iPadOS 17.7.11（21H461）**。

| 项 | 值 |
| --- | --- |
| 工作目录 | `/Users/diannao/pad7pro-xnu`（记作 `$W`） |
| 设备 serial | `a20248f7`（bootloader 已解锁，`verifiedbootstate=orange`） |
| 当前状态 | **能进 iOS 系统，电源/音量下两键实测可用**（2026-10-28 晚）|
| 保底镜像 | `fw/vendor_boot_lite.img` = `c58ad307…`；git tag `peridot-desktop-works` |
| 按键基线 | `fw/vendor_boot_btn2.img` = `534125e3…`；git tag `peridot-buttons-work`（lite + data 种子 + 按键驱动）|
| iPad 根镜像 | `fw/userdata-backup/userdata-root.sparse`（`4c90d7a7…`，8.9 GB）|

---

## 1. 先读什么（按顺序）

1. `NEXT-PROMPT.md` —— 现状 + 下一步（顶部有官方优先规则和一键粘贴的精简版）
2. `HANDOFF-2026-10-27.md` —— 最新完整交接（§A–§J 是最后一个有效工作日的流水）
3. `PLAN.md` §0 —— **官方优先原则（完整版）**；其余章节是历史阶段记录
4. `HANDOFF.md` —— 早期完整细节（§0.2 列了哪些历史结论已作废，别照抄旧结论）

---

## 2. 官方优先（最高优先级，完整版见 `PLAN.md` §0）

**官方网站 <https://unixnu.com> 与官方仓库 <https://github.com/UniXNU/UniXNU> 是主体；
本工作区的实现是补充，不是替代。**

1. **先查后写** —— 实现任何驱动/机制前，先在网站与官方仓库搜索是否已有实现（含
   `/reference/components` 的规范 ID）。**有 → 接入或移植**；没有 → 才自己写，并在文档里写明
   "查过什么、为什么不复用"。
2. **用规范名** —— `ShengUfs` / `GopFramebuffer` / `AppleKeyStoreState` / `Adreno740` / `AdrenoMetal` /
   `ShengNovatekTouch` / `QcomGeniSpi`。`NativeUfs` / `NativeMobileDisplay` / `NativeKeyStoreEvents`
   只是历史别名。对照表：网站 `/porting/migration`。
3. **改动落在补丁/组件层** —— 不整目录复制上游文件后原地改；优先 `patches/xnu/series`、组件 pin、
   板级 `package/`。
4. **开工先对表** ——
   ```bash
   git -C $W/UniXNU fetch
   git -C $W/UniXNU rev-list --left-right --count origin/main...HEAD   # 落后 / 领先
   ```
   把这个数字写进当天交接。**落后 > 50 个提交就安排一次对齐。**
   （2026-10-27 审计：当时落后 **153** 个提交，设备仓库还是**格式 1**，另有 **49 个文件未提交**。）
5. **冲突以官方为准** —— 本地行为与官方文档/实现冲突时，先在 `PLAN.md` 记录差异与理由再决定偏离，
   **不允许静默偏离**。

### 2.1 已知"我们造过、上游已有"的东西 —— 不要再重造

| 本工作区的实现 | 官方已有 |
| --- | --- |
| 屏幕 dump 通道（panic → 冻屏 → 拍照）| `package/BootLog.c` + `BootReset.c` + `package/linux-log/` + `scripts/read-sheng-log.py`（全自动，网站 `/porting/log-capture`）|
| CPU 逐帧扫描拷贝（~1.4 fps）| 显示 `GopFramebuffer`；加速 `Adreno740` + `AdrenoMetal`（网站 `/porting/gpu`）|
| 自研 AppleKeyStore（`NativeKeyStoreEvents`）| `AppleKeyStoreState` |
| 自己写的 SoC 参数 | 共用 SoC 支持 `UniXNU-sm8550-common` |

---

## 3. 构建与上机（当前最简路径）

```bash
W=/Users/diannao/pad7pro-xnu; P=/opt/homebrew/bin/python3.12
export PATH=/opt/homebrew/bin:/opt/homebrew/opt/llvm/bin:/opt/homebrew/opt/lld/bin:$PATH

# 内核（只有改了 package/ drivers/ patches/ 才需要，约 5–12 分钟）
cd $W/UniXNU && $P unixnu build kernel -D ../UniXNU-peridot \
   --kernelcache out/ipsw/21H461/kernelcache.decompressed

# payload + vendor_boot（只改 board.toml 时只需这两步，约 1 分钟）
# ★★ --data-ramdisk 不能省：没有它 native_owner_data_prepare() 返回 ENOENT(2)，
#    load_init_program 立刻 panic("offline scratch Data mount failed: 2")，镜像永远到不了系统。
#    2026-10-28 的 buttons/diag 镜像全部栽在这里（HANDOFF-2026-10-28 §11）。
$P unixnu build payload -D ../UniXNU-peridot --kernel out/peridot/kernel/kernel.macho \
   --unique-chip-id 0000000000000001 --owner-trust-cache /tmp/peridot-static-system.bundle \
   --data-ramdisk ../fw/data-seed/peridot-data-200g.dbr
# --base 用 lite（已验证可用的 vendor_boot），不是 stock：
#   patch-vendor-boot.py 只从 base 取 header/DTB/fragment 表/bootconfig，
#   真正的内核参数来自 payload 里的 ADT，所以 boot-arg 改动走 payload 即可。
$P ../UniXNU-peridot/scripts/patch-vendor-boot.py --base ../fw/vendor_boot_lite.img \
   --payload out/peridot/payload/payload.img --output ../fw/vendor_boot_<名字>.img

# 上机：★ 只用这个脚本，不要手敲 fastboot。
#   它负责 preflight（槽位/电量/镜像校验）、分区白名单、自动 --set-active、写台账，
#   并且从不使用 fastboot reboot。
$W/tools/peridot-flash-mode.sh status                      # 看本地镜像 + 设备 + 槽位
$W/tools/peridot-flash-mode.sh preflight                   # 实验前检查并修复 slot-unbootable
$W/tools/peridot-flash-mode.sh xnu fw/vendor_boot_<名字>.img
$W/tools/peridot-flash-mode.sh stock                       # 只充电模式（原厂 vendor_boot）
$W/tools/peridot-flash-mode.sh restore-stock --yes         # boot/vendor_boot/recovery 全部回原厂
$W/tools/peridot-flash-mode.sh ledger                      # 这一台刷过什么
```

**回原厂安卓**（会毁掉 iPadOS 根，见 §5 第 10 条）：
```bash
fastboot flash vendor_boot fw/stock/vendor_boot.img   # 换回安卓的 vendor_boot
# 然后进 recovery：Wipe data/factory reset（fastboot erase userdata 不会建 f2fs）
```

`board.toml` 的 boot-args 有**约 1000 字节上限**，加参数前先数长度。
产物一律记录 `sha256` 并写清"哪个配置最好"。

---

## 4. 记录义务

- **每次改动写进当天的交接文档**（`HANDOFF-<日期>.md`，按"一节一轮"追加，编号越大越新）。
- **不要把工作留在未提交状态。** 每个可启动的配置至少一次 commit，必要时打 tag。
- 产物命名：`fw/vendor_boot_<用途>.img`；日志放 `logs/`（照片、构建日志、刷写日志）。
- 结论要带证据：数字（sha256、秒数、计数器）和复现命令，不写"应该/可能"。

---

## 5. 硬性禁令（每条都有过事故）

1. **`fastboot getvar` 不要接 `head` / `| grep -m1`** —— SIGPIPE 会让 fastboot 半路退出，**设备端
   fastboot 服务随之卡死**，`getvar`/`flash` 全部挂起，拔插 USB 也救不回，只能强制关机重进。
   正确做法：`fastboot getvar all > /tmp/fb.txt 2>&1` 之后再 grep。
2. **不要在设备 UI 里点「抹掉」/ 还原** —— `com.apple.mobile.obliteration` 已被 `sheng-lite=1` 停掉，
   点了大概率卡死；要干净重刷用
   `fastboot flash userdata fw/userdata-backup/userdata-root.sparse`。
3. **不要砍 `offline-legacy-*` / `offline-mobile-graphics-*`** —— 砍了连 logo 都到不了（实测两次）。
4. **不要锁回 bootloader**（`fastboot flashing lock`）。
5. **充电必须用墙充（5V/2A+）** —— 电脑 USB 500 mA 会让设备陷入"充电图标↔尝试启动"死循环。
6. **注意发热** —— 本 port **没有热管理**（无 thermal zone、无 DVFS、`wdt=-1`），CPU 逐帧拷贝
   常驻约 40% 一个核。长时间测试要间歇、且**不要无人值守地挂着**。
7. **长时间 panic/dump 之前先确认通道可用** —— panic 路径会抓 stackshot，历史上会被断言顶掉；
   详见 `HANDOFF-2026-10-27.md` §C / §G。
8. **清理空间时不要删 `UniXNU/out/ipsw`** —— 它是全工作区**唯一需要联网才能恢复**的缓存（IPSW 解包，
   kernelcache 与根镜像都在里面）。要清就清 `fw/` 下被取代的镜像和 `logs/` 里的历史录像。
9. **不要手敲 `fastboot flash boot` / `fastboot flash recovery` / `fastboot reboot`**。
   2026-10-28 两次把设备弄到需要全量线刷，都是这三条。上机一律走
   `tools/peridot-flash-mode.sh`；只有 `restore-stock --yes` 才允许写 boot/recovery。
10. **不要把 vendor_boot 做得明显小于 48 MiB**。能用的 payload 镜像都是 **61.81 MiB**；
   把 vendor ramdisk 缩小是 2026-10-28 设备失联的直接前因（脚本会拦）。
11. **`userdata` 一旦被原厂安卓格式化，iPadOS 就起不来** —— 报
   `Failed to mount root device @IOKitBSDInit.cpp:984`。回到安卓再测 XNU 之前，
   必须先 `fastboot flash userdata fw/userdata-backup/userdata-root.sparse`（8.9 GB，约 3.5 分钟）。
12. **删任何东西之前先确认它不是唯一副本** —— 已知唯一副本：`fw/userdata-backup/userdata-root.sparse`、
   `fw/vendor_boot_lite.img`、`UniXNU` 仓库里那 193 个未提交改动、全部 `*.md`。

---

## 6. 当前的下一步（按顺序，2026-10-28 深夜更新）

1. ~~上机流程硬化~~ —— **本场已完成**：`tools/peridot-flash-mode.sh` 重写为唯一入口
   （preflight、分区白名单、自动 `--set-active`、镜像 `<48 MiB` 拦截、`logs/flash-ledger.tsv` 台账），
   §5 新增第 9/10 条禁令。**以后上机一律用它，不要手敲 fastboot。**
2. **显示 / GPU（1.4 fps）—— 现在的主线**。CPU 逐帧拷贝把合成器压到 ~1.4 fps，
   所有 UI 判断因此不可信（10-27 的二分就是被那条假进度条毁掉的）。
   官方组件：`GopFramebuffer`（显示）、`Adreno740` + `AdrenoMetal`（加速），见网站 `/porting/gpu`。
3. **启动确定性**：同一镜像既进过桌面也卡过（HANDOFF-2026-10-27 §K.7），至今没解释。
   这是所有实验的地基；在能机读日志前，至少要用固定判据 + 多次采样。
4. **热与电源**：无 thermal zone、无 DVFS、`wdt=-1`（§5 第 6 条）。这是**安全**问题，不是体验问题。
5. **音量上键的 PPID**：从 stock DTB 的 `gpio-keys` 节点读，不要用 `peridot-buttons-scan=1`
   （会遍历所有 APID 读 obsrvr，可能同步外部中止 panic）。电源键偶发两下同理核对去抖。
6. **格式 2 迁移**：`schema_version = 2` + 共用 SoC/OS profile + 规范组件，分支上做，
   `fw/vendor_boot_btn2.img` 当保底。
7. **日志通道（暂停）**：10-28 晚把三条路都试到底了（HANDOFF-2026-10-28 §14–§18）：
   XNU 内 USB 控制台卡在 USB3 PHY；DDR ramoops 过 bootloader 就丢；
   官方 UFS writer 已移植进内核、但**没有 reader**（stock recovery 的 adbd 无 root，
   TWRP/OrangeFox 是 ramdisk-only 镜像起不来）。要继续需要 **peridot 的 mainline Linux 内核**
   来跑官方 Linux reader；组件（`package/linux-log/init` + `scripts/build-peridot-log-reader.py` +
   静态 busybox）都已就绪。

