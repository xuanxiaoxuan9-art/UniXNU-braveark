/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#include "PeridotGmuSmmu.h"
#include <string.h>

#define PAGE 4096u

static uint64_t extent_iova(unsigned index)
{
    switch(index) {
    case PERIDOT_GMU_ICACHE: return PERIDOT_GMU_ICACHE_IOVA;
    case PERIDOT_GMU_DUMMY:  return PERIDOT_GMU_DUMMY_IOVA;
    case PERIDOT_GMU_LOG:    return PERIDOT_GMU_LOG_IOVA;
    case PERIDOT_GMU_HFI:    return PERIDOT_GMU_HFI_IOVA;
    default:              return PERIDOT_GMU_DEBUG_IOVA;
    }
}

static size_t extent_bytes(unsigned index)
{
    switch(index) {
    case PERIDOT_GMU_ICACHE: return PERIDOT_GMU_ICACHE_BYTES;
    case PERIDOT_GMU_DUMMY:  return PERIDOT_GMU_DUMMY_BYTES;
    case PERIDOT_GMU_DEBUG:  return PERIDOT_GMU_DEBUG_BYTES;
    case PERIDOT_GMU_LOG:    return PERIDOT_GMU_LOG_BYTES;
    default:              return PERIDOT_GMU_HFI_BYTES;
    }
}

/* Ascending native IOVA order: it is both the order the updater requires and the order
 * the table walk visits. */
static const unsigned sorted[PERIDOT_GMU_EXTENTS] = {
    PERIDOT_GMU_ICACHE, PERIDOT_GMU_DUMMY, PERIDOT_GMU_LOG, PERIDOT_GMU_HFI, PERIDOT_GMU_DEBUG
};

static unsigned permissions(unsigned index)
{
    unsigned perms = ArmSmmu4KRead | ArmSmmu4KWrite | ArmSmmu4KPrivileged;
    if (index == PERIDOT_GMU_ICACHE) perms |= ArmSmmu4KExecute;   /* firmware executes there */
    return perms;
}

static int aligned(uint64_t value) { return !(value & (PAGE - 1)); }
static int overlaps(uint64_t a, uint64_t abytes, uint64_t b, uint64_t bbytes)
{
    return a < b + bbytes && b < a + abytes;
}

size_t PeridotGmuSmmuTablePages(const PeridotGmuSmmuPlan *plan)
{
    (void)plan;
    /* Mirrors ArmSmmu4KLivePrepare's layout() for the fixed aperture below: one level-1
     * root, one level-2 table per 1 GiB span (2 here) and one level-3 table per 2 MiB span
     * (771 here, from 0x4000 to 0x60406fff). Leaf descriptors live inside those pages, so
     * the mapped pages do not need table storage of their own. */
    const uint64_t low = PERIDOT_GMU_ICACHE_IOVA;
    const uint64_t high = PERIDOT_GMU_DEBUG_IOVA + PERIDOT_GMU_DEBUG_BYTES - 1;
    size_t pages = 1;
    for (unsigned level = 1; level < 3; ++level) {
        unsigned shift = 39 - 9 * level;
        pages += (size_t)((high >> shift) - (low >> shift) + 1);
    }
    return pages;
}

size_t PeridotGmuSmmuRanges(const PeridotGmuSmmuPlan *plan, ArmSmmu4KRange *out, size_t capacity)
{
    size_t count = 0;
    if (!plan || !out || capacity < PERIDOT_GMU_EXTENTS) return 0;
    for (unsigned i = 0; i < PERIDOT_GMU_EXTENTS; ++i) {
        const unsigned index = sorted[i];
        const PeridotGmuSmmuExtent *e = &plan->extents[index];
        out[count++] = (ArmSmmu4KRange){
            .iova = e->iova, .physical = e->physical, .bytes = e->bytes,
            .permissions = permissions(index),
            .writeback = 0,           /* Normal non-cacheable, as the vendor maps GMU RAM */
            .shareability = 2,        /* outer shareable, the A735 GMU mapping */
        };
    }
    return count;
}

const char *PeridotGmuSmmuOutcomeText(PeridotGmuSmmuOutcome outcome)
{
    switch (outcome) {
    case PeridotGmuSmmuDone:          return "done";
    case PeridotGmuSmmuArgument:      return "argument";
    case PeridotGmuSmmuPrepareFailed: return "prepare";
    case PeridotGmuSmmuPublishFailed: return "publish";
    case PeridotGmuSmmuStartFailed:   return "start";
    case PeridotGmuSmmuMapFailed:     return "map";
    default:                       return "observe";
    }
}

static ArmSmmu4KStatus validate(const ArmSmmu4KIo *io, const PeridotGmuSmmuPlan *plan,
    const PeridotGmuSmmuCache *cache)
{
    if (!io || !plan || !cache || !cache->publish) return ArmSmmu4KArgument;
    if (!io->read32 || !io->read64 || !io->write32 || !io->write64 || !io->barrier ||
        io->register_bytes != SHENG_GPU_SMMU_BYTES) return ArmSmmu4KArgument;
    if (plan->bank < SHENG_GPU_SMMU_GMU_BANK_MIN || plan->bank > 255 ||
        plan->slot > 255 || !plan->poll_budget || plan->poll_budget > 1048576)
        return ArmSmmu4KArgument;
    const PeridotGmuSmmuPool *pool = &plan->pool;
    const uint64_t physical_limit = UINT64_C(1) << PERIDOT_GMU_OUTPUT_BITS;
    if (!pool->cpu || !aligned((uintptr_t)pool->cpu) || !aligned(pool->physical) ||
        !pool->capacity_pages || pool->capacity_pages > (1u << 20) ||
        pool->physical >= physical_limit ||
        pool->capacity_pages * (uint64_t)PAGE > physical_limit - pool->physical)
        return ArmSmmu4KArgument;
    if (pool->capacity_pages < PeridotGmuSmmuTablePages(plan)) return ArmSmmu4KBudget;
    for (unsigned i = 0; i < PERIDOT_GMU_EXTENTS; ++i) {
        const PeridotGmuSmmuExtent *e = &plan->extents[i];
        if (!e->cpu || !aligned((uintptr_t)e->cpu) || !aligned(e->physical) ||
            !aligned(e->iova) || !aligned((uint64_t)e->bytes) || !e->bytes ||
            e->iova != extent_iova(i) || e->bytes != extent_bytes(i) ||
            e->physical >= physical_limit ||
            e->bytes > physical_limit - e->physical ||
            e->iova >= (UINT64_C(1) << PERIDOT_GMU_INPUT_BITS) ||
            e->bytes > (UINT64_C(1) << PERIDOT_GMU_INPUT_BITS) - e->iova)
            return ArmSmmu4KArgument;
        for (unsigned j = 0; j < i; ++j) {
            const PeridotGmuSmmuExtent *o = &plan->extents[j];
            if (overlaps(e->physical, e->bytes, o->physical, o->bytes) ||
                overlaps(e->iova, e->bytes, o->iova, o->bytes) ||
                overlaps((uintptr_t)e->cpu, e->bytes, (uintptr_t)o->cpu, o->bytes))
                return ArmSmmu4KOverlap;
        }
        if (overlaps(e->physical, e->bytes, pool->physical, pool->capacity_pages * (uint64_t)PAGE) ||
            overlaps((uintptr_t)e->cpu, e->bytes, (uintptr_t)pool->cpu, pool->capacity_pages * (uint64_t)PAGE))
            return ArmSmmu4KOverlap;
    }
    return ArmSmmu4KSuccess;
}

/* The ID registers this QSMMU v500 reports to non-secure software carry only their low
 * byte: IDR0=0x18 (24 SMR groups, but no stage-1/AArch64 capability bits), IDR1=0x16
 * (22 banks, 4 KiB stride, but the context-bank page count field reads 0 = 2 pages) and
 * IDR2=0x02 (no 4 KiB page-table bit, no VA/OAS width). ArmSmmu4K refuses that identity,
 * and its 2-page derivation would put context bank 2 at 0x4000 -- which is the QSMMU's
 * IMPL_DEF page on this board and takes a synchronous external abort (measured 2026-10-29:
 * panic at the `ldr` for window+0x4000, logs/2026-10-29-21-17-49-960.jpg). The bank space
 * is really at 0x20000: the DT maps 0x3DA0000+0x40000 for 22 banks, and window+0x22000
 * reads back. So the library is shown the capability fields the hardware omits and
 * nothing else: 10-bit stream IDs (DT qcom,stream-id-range 0x00..0x400), 32 bank pages,
 * stage-1 AArch64, 4 KiB tables, 40-bit VA and PA. The raw
 * values stay what the probe reads; this view never reaches a register (all IDR registers
 * are read-only) and is deterministic, so the library's own re-read consistency checks
 * still hold. */
typedef struct {
    const ArmSmmu4KIo *real;
} PeridotGmuSmmuIdView;

static int view_read32(void *cookie, size_t at, uint32_t *v)
{
    const PeridotGmuSmmuIdView *view = cookie;
    if (view->real->read32(view->real->cookie, at, v)) return 1;
    if (at == 0x20) *v |= PERIDOT_GMU_ID0_VIEW;
    else if (at == 0x24) *v = (*v & ~PERIDOT_GMU_ID1_PAGE_MASK) | PERIDOT_GMU_ID1_PAGES;
    else if (at == 0x28) *v = PERIDOT_GMU_ID2_VIEW | (*v & 0xfu);
    return 0;
}

static int view_read64(void *cookie, size_t at, uint64_t *v)
{
    return ((const PeridotGmuSmmuIdView *)cookie)->real->read64(((const PeridotGmuSmmuIdView *)cookie)->real->cookie, at, v);
}

static int view_write32(void *cookie, size_t at, uint32_t v)
{
    return ((const PeridotGmuSmmuIdView *)cookie)->real->write32(((const PeridotGmuSmmuIdView *)cookie)->real->cookie, at, v);
}

static int view_write64(void *cookie, size_t at, uint64_t v)
{
    return ((const PeridotGmuSmmuIdView *)cookie)->real->write64(((const PeridotGmuSmmuIdView *)cookie)->real->cookie, at, v);
}

static int view_barrier(void *cookie)
{
    return ((const PeridotGmuSmmuIdView *)cookie)->real->barrier(((const PeridotGmuSmmuIdView *)cookie)->real->cookie);
}

static int publish_page(void *cookie, volatile uint64_t *page, size_t bytes)
{
    PeridotGmuSmmu *state = cookie;
    const PeridotGmuSmmuPool *pool = &state->plan.pool;
    if (!page || !bytes || (bytes & (PAGE - 1)) || ((uintptr_t)page & (PAGE - 1)))
        return 1;
    const uintptr_t base = (uintptr_t)pool->cpu;
    const uintptr_t at = (uintptr_t)page;
    if (at < base || at - base >= pool->capacity_pages * PAGE) return 1;
    if (bytes > pool->capacity_pages * PAGE - (at - base)) return 1;
    return state->publish ? state->publish(state->publish_cookie,
        pool->physical + (at - base), bytes) : 1;
}

/* ArmSmmu4K now takes table pages on demand instead of a preallocated block. The plan still owns one
 * contiguous extent, so the three callbacks below hand out that extent one page at a time: the first
 * allocate() returns its base, the next returns base+1 page, and find()/overlaps() answer from the same
 * bounds. Nothing is allocated lazily beyond what the walk asks for. */
static int a4k_allocate(void *cookie, uint64_t *physical, volatile uint64_t **mapping)
{
    /* The first page of the pool is the root table the plan already publishes
     * (config.table_physical), so allocation starts at page 1: handing the root out again would
     * make two tables share one frame and ArmSmmu4KLive rejects that as a state mismatch. */
    PeridotGmuSmmu *state = cookie;
    const PeridotGmuSmmuPool *pool = &state->plan.pool;
    if (!pool->cpu || pool->capacity_pages < 2) return 1;
    if (state->pages_taken == 0) state->pages_taken = 1;
    if (state->pages_taken >= pool->capacity_pages) return 1;
    const uint64_t physical_page = pool->physical + (uint64_t)state->pages_taken * PAGE;
    volatile uint64_t *cpu_page =
        (volatile uint64_t *)((uintptr_t)pool->cpu + (uintptr_t)state->pages_taken * PAGE);
    memset((void *)cpu_page, 0, PAGE);
    ++state->pages_taken;
    if (physical) *physical = physical_page;
    if (mapping) *mapping = cpu_page;
    return 0;
}

static volatile uint64_t *a4k_find(void *cookie, uint64_t physical)
{
    /* The plan owns the whole extent up front, so every page of it is addressable from the start:
     * the root table (config.table_physical) is asked for before any allocate() has run, and
     * ArmSmmu4KLive refuses the arena outright when find() cannot answer for it. */
    PeridotGmuSmmu *state = cookie;
    const PeridotGmuSmmuPool *pool = &state->plan.pool;
    if (!pool->cpu || physical < pool->physical) return 0;
    const uint64_t offset = physical - pool->physical;
    if (offset >= (uint64_t)pool->capacity_pages * PAGE || (offset & (PAGE - 1))) return 0;
    return (volatile uint64_t *)((uintptr_t)pool->cpu + (uintptr_t)offset);
}

static int a4k_overlaps(void *cookie, uint64_t physical, uint64_t bytes)
{
    PeridotGmuSmmu *state = cookie;
    const PeridotGmuSmmuPool *pool = &state->plan.pool;
    if (!pool->capacity_pages) return 0;
    return overlaps(physical, bytes, pool->physical, (uint64_t)pool->capacity_pages * PAGE);
}

PeridotGmuSmmuOutcome PeridotGmuSmmuRun(const ArmSmmu4KIo *io, const PeridotGmuSmmuPlan *plan,
    const PeridotGmuSmmuCache *cache, PeridotGmuSmmu *state)
{
    if (!state) return PeridotGmuSmmuArgument;
    state->publish = cache ? cache->publish : 0;
    state->publish_cookie = cache ? cache->cookie : 0;
    memset(&state->summary, 0, sizeof state->summary);
    state->session = (ShengGpuSmmuSession){0};
    state->state = (ArmSmmu4KLiveState){0};
    state->started = (ShengGpuSmmuResult){0};
    state->observed = (ShengGpuSmmuResult){0};
    state->mapping = (ArmSmmu4KLiveResult){0};

    ArmSmmu4KStatus status = validate(io, plan, cache);
    if (status != ArmSmmu4KSuccess) {
        state->summary.outcome = PeridotGmuSmmuArgument;
        state->summary.prepare_status = status;
        return PeridotGmuSmmuArgument;
    }
    state->plan = *plan;

    PeridotGmuSmmuIdView id_view = { io };
    ArmSmmu4KIo shim = *io;
    shim.cookie = &id_view;
    shim.read32 = view_read32;
    shim.read64 = view_read64;
    shim.write32 = view_write32;
    shim.write64 = view_write64;
    shim.barrier = view_barrier;

    ArmSmmu4KRange ranges[PERIDOT_GMU_EXTENTS];
    const size_t count = PeridotGmuSmmuRanges(&state->plan, ranges, PERIDOT_GMU_EXTENTS);
    memcpy(state->ranges, ranges, sizeof ranges);
    const PeridotGmuSmmuPool *pool = &state->plan.pool;
    const uint64_t iova = PERIDOT_GMU_ICACHE_IOVA;
    const uint64_t bytes = PERIDOT_GMU_DEBUG_IOVA + PERIDOT_GMU_DEBUG_BYTES - iova;

    state->pages_taken = 0;
    state->pages = (ArmSmmu4KTablePages){ state, a4k_allocate, a4k_find, a4k_overlaps };
    state->arena = (ArmSmmu4KLiveArena){
        .config = { PERIDOT_GMU_INPUT_BITS, PERIDOT_GMU_OUTPUT_BITS, pool->physical,
                    (size_t)(bytes / PAGE) },
        .iova = iova, .bytes = bytes, .upper_region = 0,
        .pages = &state->pages,
        .alias_scratch = state->alias_scratch,
        .alias_scratch_entries = PERIDOT_GMU_EXTENTS,
    };
    state->visibility = (ArmSmmu4KLiveVisibility){ state, publish_page };

    /* 1. All intermediate tables, still empty; the GMU is held in reset, so a published
     *    but leaf-less context cannot translate anything yet. */
    memset(pool->cpu, 0, pool->capacity_pages * PAGE);
    state->summary.phase = 1;
    state->summary.capacity_pages = pool->capacity_pages;
    state->summary.arena_iova = iova;
    state->summary.arena_bytes = bytes;
    state->summary.table_physical = pool->physical;
    state->summary.bank = state->plan.bank;
    state->summary.slot = state->plan.slot;
    state->summary.extents = PERIDOT_GMU_EXTENTS;
    status = ArmSmmu4KLivePrepare(&state->arena, &state->state);
    state->summary.prepare_status = status;
    state->summary.table_pages = state->state.tables.table_pages;
    if (status != ArmSmmu4KSuccess) {
        state->summary.outcome = PeridotGmuSmmuPrepareFailed;
        return PeridotGmuSmmuPrepareFailed;
    }

    /* 2. Publish the tables and the staged GMU image, as the device walks them. */
    state->summary.phase = 2;
    if (cache->publish(cache->cookie, pool->physical,
            state->state.tables.table_pages * (size_t)PAGE)) {
        state->summary.outcome = PeridotGmuSmmuPublishFailed;
        return PeridotGmuSmmuPublishFailed;
    }
    for (unsigned i = 0; i < PERIDOT_GMU_EXTENTS; ++i)
        if (cache->publish(cache->cookie, state->plan.extents[i].physical,
                state->plan.extents[i].bytes)) {
            state->summary.outcome = PeridotGmuSmmuPublishFailed;
            return PeridotGmuSmmuPublishFailed;
        }

    /* 3. Program the disabled GMU context bank, attach stream 5 and observe it. */
    state->context = (ArmSmmu4KContextConfig){
        .lower = &state->arena.config,
        .upper = 0,
        .lower_tables = &state->state.tables,
        .upper_tables = 0,
        .id0 = 0, .id2 = 0,          /* the programmer overwrites these with real reads */
        .asid = state->plan.bank + 1,
        .coherent_walk = 1,
        .stall_on_fault = 0,
        .continue_after_fault = 1,   /* required by the pinned Adreno SMMU writer */
    };
    state->summary.phase = 3;
    unsigned slots[1] = { state->plan.slot };
    status = ShengGpuSmmuStartLive(&shim, SHENG_GPU_SMMU_BASE, ShengGpuSmmuGmu, state->plan.bank,
        slots, 1, &state->context, &state->arena, &state->state, state->plan.poll_budget,
        &state->session, &state->started);
    state->summary.start_status = status;
    state->summary.start_phase = state->started.phase;
    state->summary.start_writes = state->started.context.writes;
    state->summary.start_poll_reads = state->started.context.poll_reads;
    state->summary.context_offset = state->started.context.context_offset;
    state->summary.id0 = state->started.context.id0;
    state->summary.id1 = state->started.context.id1;
    state->summary.id2 = state->started.context.id2;
    state->summary.scr0 = state->started.streams.scr0;
    state->summary.global_fault = state->started.streams.global_fault;
    state->summary.streams_bank = state->session.streams.bank;
    state->summary.streams_count = state->session.streams.count;
    if (status != ArmSmmu4KSuccess) {
        state->summary.outcome = PeridotGmuSmmuStartFailed;
        return PeridotGmuSmmuStartFailed;
    }
    state->summary.leaf_pages = state->state.tables.leaf_pages;

    /* 4. Map the five extents one at a time. The single-region updater takes the set of
     *    already-mapped ranges as `before` and re-checks it, so the calls grow that set:
     *    every transaction proves all earlier mappings again, and a failure at extent k
     *    leaves exactly k-1 of them installed and reported. */
    state->summary.phase = 4;
    ArmSmmu4KRange before[PERIDOT_GMU_EXTENTS];
    for (size_t i = 0; i < count; ++i) {
        state->mapping = (ArmSmmu4KLiveResult){0};
        status = ArmSmmu4KLiveUpdate(&state->arena, &state->state, &shim, state->plan.bank,
            &state->context, &state->visibility, i ? before : 0, i, &state->ranges[i], 1,
            state->plan.poll_budget, &state->mapping);
        state->summary.map_status = status;
        state->summary.map_published += state->mapping.published_pages;
        state->summary.map_descriptor_writes += state->mapping.descriptor_writes;
        state->summary.leaf_pages = state->state.tables.leaf_pages;
        if (status != ArmSmmu4KSuccess) {
            state->summary.mapped = (unsigned)i;
            state->summary.outcome = PeridotGmuSmmuMapFailed;
            return PeridotGmuSmmuMapFailed;
        }
        before[i] = state->ranges[i];
        state->summary.mapped = (unsigned)i + 1;
    }

    /* 5. Context, streams and every mapped extent again. */
    state->summary.phase = 5;
    status = ShengGpuSmmuObserveLive(&shim, SHENG_GPU_SMMU_BASE, &state->session,
        state->ranges, count, &state->observed);
    state->summary.observe_status = status;
    if (status != ArmSmmu4KSuccess) {
        state->summary.outcome = PeridotGmuSmmuObserveFailed;
        return PeridotGmuSmmuObserveFailed;
    }
    state->summary.outcome = PeridotGmuSmmuDone;
    return PeridotGmuSmmuDone;
}
