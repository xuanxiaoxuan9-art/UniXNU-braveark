// SPDX-License-Identifier: BSD-2-Clause-Patent
// Bounded offline original lifecycle instrument; no desktop claim.
#include <IOKit/IOPlatformExpert.h>
#include <IOKit/IODeviceMemory.h>
#include <IOKit/IOBufferMemoryDescriptor.h>
#include <IOKit/IODeviceTreeSupport.h>
#include <IOKit/IOLib.h>
#include <IOKit/IOUserClient.h>
#include <libkern/c++/OSMetaClass.h>
#include <libkern/c++/OSSerialize.h>
#include <libkern/c++/OSData.h>
#include <kern/task.h>
#include <sys/proc.h>
#include <pexpert/pexpert.h>
#include <mach/kmod.h>
#include <machine/machine_routines.h>
extern "C" kmod_info_t g_kernel_kmod_info;
extern "C" void native_legacy_display_static_init(void) __asm__("__GLOBAL__sub_I_NativeLegacyDisplay.cpp");
extern "C" IOService *native_legacy_display_allocate(void);
extern "C" void native_gop_presenter_static_init(void) __asm__("__GLOBAL__sub_I_NativeGOPPresenter.cpp");
extern "C" IOService *native_gop_presenter_create(void);
static IOService *pendingLegacyDisplay;
static IOService *activeGOPPresenter,*activeGOPNub;
static IOService *activeLegacyDisplay;
// Keep one diagnostic mapping alive until reboot, even after backend stop.
// The pulse is permanently closed before any system-frame copy.
static IOMemoryMap *diagnosticAnchorMapping;
extern "C" int boot_progress_pulse_anchor(uintptr_t,uint64_t,unsigned,unsigned,unsigned) __attribute__((weak_import));
static IORegistryEntry *unitScaleChosen;
static bool unitScaleAdded,unitRotationAdded;
static void finishUnitScalePolicy(bool keep) {
    if(unitScaleChosen && !keep) {
        if(unitScaleAdded)unitScaleChosen->removeProperty("display-scale");
        if(unitRotationAdded)unitScaleChosen->removeProperty("display-rotation");
    }
    OSSafeReleaseNULL(unitScaleChosen);unitScaleAdded=false;unitRotationAdded=false;
}
static bool publishOrMatchWord(IORegistryEntry *entry,const char *key,uint32_t value,bool &added) {
    OSObject *previous=entry->getProperty(key);
    if(previous) {
        OSData *data=OSDynamicCast(OSData,previous);uint32_t word=0;
        if(!data || data->getLength()!=sizeof(word))return false;
        memcpy(&word,data->getBytesNoCopy(),sizeof(word));return word==value;
    }
    OSData *data=OSData::withBytes(&value,sizeof(value));
    bool result=data && entry->setProperty(key,data);OSSafeReleaseNULL(data);added=result;return result;
}
// Bring-up: text console park/unpark (osfmk/console/video_console.c).
extern "C" void vc_set_text_quiet(int) __attribute__((weak_import));
extern "C" {
volatile uint32_t native_legacy_stage;
volatile uint32_t native_legacy_console_quiet;
volatile int native_legacy_meta_status=-1;
volatile uint32_t native_legacy_init_result,native_legacy_start_result,native_legacy_probe_match;
volatile uint32_t native_legacy_parent_match,native_legacy_object_size,native_legacy_released;
volatile uint64_t native_legacy_object,native_legacy_nub,native_legacy_workloop;
volatile uint32_t native_legacy_guard_slot;
volatile uint64_t native_legacy_guard_object,native_legacy_guard_caller;
volatile int native_legacy_surface_status=-1;
volatile uint32_t native_legacy_surface_found;
volatile uint64_t native_legacy_video_base,native_legacy_video_bytes;
volatile uint64_t native_legacy_gop_map,native_legacy_gop_virtual,native_legacy_gop_physical,native_legacy_gop_bytes;
volatile uint32_t native_legacy_gop_width,native_legacy_gop_height;
volatile uint32_t native_legacy_registration_calls,native_legacy_properties_length;
volatile uint32_t native_legacy_dt_attached;
volatile int native_legacy_unit_scale_status=-1;
volatile uint32_t native_legacy_unit_scale_calls,native_legacy_chosen_scale,native_legacy_chosen_rotation;
volatile uint32_t native_legacy_pm_stage,native_legacy_pm_calls,native_legacy_pm_callbacks,native_legacy_pm_ordinal;
volatile int native_legacy_pm_status=-1;
volatile uint32_t native_legacy_swap_validation_calls,native_legacy_swap_validation_result,native_legacy_swap_validation_reason;
volatile uint64_t native_legacy_swap_request,native_legacy_swap_surface;
volatile uint32_t native_legacy_transfer_calls;
volatile int native_legacy_transfer_status=-1;
volatile uint64_t native_legacy_transfer_bytes,native_legacy_transfer_request;
volatile uint32_t native_legacy_retirement_calls,native_legacy_retired_generation,native_legacy_presented_generation,native_legacy_retired_frames;
// Bring-up: seconds since boot (from the real counter, not the board timebase) of the last validated
// swap, the last finished transfer and the last retirement, plus the stalled swaps kickSwapQueue had
// to abandon. A dump then says when the display path stopped, not only what it counted at the end.
volatile uint32_t native_legacy_stall_recoveries,native_legacy_validate_seconds,native_legacy_xfer_seconds,native_legacy_retire_seconds;
volatile uint32_t native_legacy_scanout_wcomb;
volatile uint32_t native_legacy_blank_frames;
// Bring-up: 1 = the panic dump owns the panel. The display client keeps presenting long after the last
// useful frame of a boot, so a late dump was painted over within one frame ("small text flashes once").
// The swap validator rejects everything while this is set.
extern "C" volatile int native_legacy_swap_hold = 0;
static uint32_t native_legacy_seconds_now(void) {
    uint64_t now=0,frequency=0;
    __asm__ volatile("isb\n\tmrs %0, cntpct_el0":"=r"(now));__asm__ volatile("mrs %0, cntfrq_el0":"=r"(frequency));
    if(!frequency)frequency=19200000;
    return (uint32_t)(now/frequency);
}
volatile uint64_t native_legacy_retired_current,native_legacy_retired_pending;
char native_legacy_properties[4096];
volatile uint32_t native_legacy_client_calls,native_legacy_client_type;
volatile int native_legacy_client_pid,native_legacy_client_status=-1;
volatile uint64_t native_legacy_client_task,native_legacy_client_object;
char native_legacy_client_class[64];
extern kern_return_t OSKextLoadKextWithIdentifier(const char *);
extern int boot_progress_prepare_scanout(void) __attribute__((weak_import));
extern void boot_progress_cancel_scanout(void) __attribute__((weak_import));
extern void boot_progress_stage(const char *) __attribute__((weak_import));
volatile uint32_t native_legacy_prepare_calls,native_legacy_prepare_reason,native_legacy_prepare_attempts;
bool native_legacy_prepare_scanout(void) {
    native_legacy_prepare_calls=native_legacy_prepare_calls+1;native_legacy_prepare_reason=0;native_legacy_prepare_attempts=0;
    if (!boot_progress_prepare_scanout) return true;
    if (ml_at_interrupt_context()) {native_legacy_prepare_reason=1;return false;}
    if (!ml_get_interrupts_enabled()) {native_legacy_prepare_reason=2;return false;}
    // Yield to any in-flight diagnostic writer; never spin on a preempted
    // holder or claim a frame that the console can still overwrite.
    for (unsigned attempt=0;attempt<100;++attempt) {
        native_legacy_prepare_attempts=attempt+1;
        if (boot_progress_prepare_scanout()) return true;
        IOSleep(1);
    }
    native_legacy_prepare_reason=3;
    if(boot_progress_cancel_scanout)boot_progress_cancel_scanout();
    return false;
}
__attribute__((noinline)) void native_legacy_display_checkpoint(void) {__asm__ volatile("" ::: "memory");}
__attribute__((noinline)) void native_legacy_gop_mapping_checkpoint(void) {__asm__ volatile("" ::: "memory");}
__attribute__((noinline)) void native_legacy_client_checkpoint(void) {__asm__ volatile("" ::: "memory");}
void native_legacy_pm_observed(unsigned stage,IOReturn status,unsigned long ordinal) {
    native_legacy_pm_stage=stage;native_legacy_pm_status=status;native_legacy_pm_ordinal=(uint32_t)ordinal;
    native_legacy_pm_calls=native_legacy_pm_calls+1;
    if(stage==3)native_legacy_pm_callbacks=native_legacy_pm_callbacks+1;
}
__attribute__((noinline)) void native_legacy_swap_validation_checkpoint(bool,unsigned,const void *,const void *) {__asm__ volatile("" ::: "memory");}
// Last rejected swap request, copied from the original request layout the validator reads (offsets
// qualified in NativeLegacyDisplay::validateSwap). Observation only; nothing here changes the verdict.
volatile uint32_t native_legacy_swap_accepted_count,native_legacy_swap_rejected_count,native_legacy_rej_reason;
volatile uint64_t native_legacy_rej_surfaces[4];
volatile uint32_t native_legacy_rej_state[3],native_legacy_rej_options[3],native_legacy_rej_size[2],native_legacy_rej_rects[2][4];
char native_legacy_rej_class[32];
static void recordRejectedSwap(unsigned reason,const void *request,const void *surface) {
    const unsigned char *bytes=reinterpret_cast<const unsigned char *>(request);
    if(!bytes)return;
    native_legacy_rej_reason=reason;
    uint64_t surfaces[4]={};memcpy(surfaces,bytes+2624,sizeof(surfaces));
    for(unsigned i=0;i<4;++i)native_legacy_rej_surfaces[i]=surfaces[i];
    const unsigned stateOffsets[3]={792,796,800},optionOffsets[3]={804,808,812};
    for(unsigned i=0;i<3;++i){uint32_t a=0,b=0;memcpy(&a,bytes+stateOffsets[i],4);memcpy(&b,bytes+optionOffsets[i],4);
        native_legacy_rej_state[i]=a;native_legacy_rej_options[i]=b;}
    uint32_t w=0,h=0;memcpy(&w,bytes+816,4);memcpy(&h,bytes+820,4);native_legacy_rej_size[0]=w;native_legacy_rej_size[1]=h;
    const unsigned rectOffsets[2]={17,81};
    for(unsigned r=0;r<2;++r){uint32_t rect[4]={};memcpy(rect,bytes+rectOffsets[r],sizeof(rect));
        for(unsigned i=0;i<4;++i)native_legacy_rej_rects[r][i]=rect[i];}
    char name[32]={};
    if(surface){const OSObject *object=reinterpret_cast<const OSObject *>(surface);
        const OSMetaClass *meta=object->getMetaClass();const char *cls=meta?meta->getClassName():nullptr;
        if(cls)strlcpy(name,cls,sizeof(name));}
    memcpy(native_legacy_rej_class,name,sizeof(name));
}
// Content statistics of presented frames (copy = kind 0, blank fill = kind 1): the first 32 are kept, with the time
// in seconds since the first frame. A per-frame record shows the animation cadence and when the OS blanks the panel.
#define NATIVE_LEGACY_FRAMES 32
volatile uint32_t native_legacy_frame_count;
volatile uint32_t native_legacy_frame_kind[NATIVE_LEGACY_FRAMES];
volatile uint32_t native_legacy_frame_time[NATIVE_LEGACY_FRAMES];
volatile uint64_t native_legacy_frame_stats[NATIVE_LEGACY_FRAMES][5];
static uint64_t frameEpoch;
void native_legacy_frame_observed(unsigned kind,uint64_t count,uint64_t minx,uint64_t miny,uint64_t maxx,uint64_t maxy) {
    uint32_t n=native_legacy_frame_count;
    uint64_t now,frequency;
    __asm__ volatile("isb\n\tmrs %0, cntpct_el0":"=r"(now));__asm__ volatile("mrs %0, cntfrq_el0":"=r"(frequency));
    if(!frameEpoch)frameEpoch=now;
    if(n<NATIVE_LEGACY_FRAMES) {
        native_legacy_frame_kind[n]=kind;
        native_legacy_frame_time[n]=frequency?(uint32_t)((now-frameEpoch)/frequency):0;
        native_legacy_frame_stats[n][0]=count;native_legacy_frame_stats[n][1]=minx;native_legacy_frame_stats[n][2]=miny;
        native_legacy_frame_stats[n][3]=maxx;native_legacy_frame_stats[n][4]=maxy;
    }
    native_legacy_frame_count=n+1;
}
volatile uint32_t native_legacy_frame_colors[8][4];
volatile uint64_t native_legacy_frame_color_counts[8][4],native_legacy_frame_color_other[8];
// Called right after the matching native_legacy_frame_observed(); fills slot count-1 (or the blank slot).
void native_legacy_frame_colors_observed(const uint32_t *colors,const uint64_t *counts,uint64_t other) {
    uint32_t n=native_legacy_frame_count;
    if(!n || n>8)return;   // dominant colours are kept for the first eight frames only
    n-=1;
    for(unsigned i=0;i<4;++i){native_legacy_frame_colors[n][i]=colors[i];native_legacy_frame_color_counts[n][i]=counts[i];}
    native_legacy_frame_color_other[n]=other;
}
void native_legacy_swap_validation_observed(bool accepted,unsigned reason,const void *request,const void *surface) {
    native_legacy_validate_seconds=native_legacy_seconds_now();
    if(accepted)native_legacy_swap_accepted_count=native_legacy_swap_accepted_count+1;
    else {native_legacy_swap_rejected_count=native_legacy_swap_rejected_count+1;recordRejectedSwap(reason,request,surface);}
    native_legacy_swap_validation_calls=native_legacy_swap_validation_calls+1;
    native_legacy_swap_validation_result=accepted;native_legacy_swap_validation_reason=reason;
    native_legacy_swap_request=(uintptr_t)request;native_legacy_swap_surface=(uintptr_t)surface;
    native_legacy_swap_validation_checkpoint(accepted,reason,request,surface);
}
// Time of the pixel copy into the scanout buffer (counter ticks): swaps completed, last/maximum/sum, for the banner.
volatile uint64_t native_legacy_copy_n,native_legacy_copy_last,native_legacy_copy_max,native_legacy_copy_sum,native_legacy_copy_bytes_last,native_legacy_copy_bytes_sum;
void native_legacy_copy_timing_observed(uint64_t ticks,uint64_t bytes) {
    native_legacy_copy_bytes_last=bytes;native_legacy_copy_bytes_sum=native_legacy_copy_bytes_sum+bytes;
    native_legacy_copy_n=native_legacy_copy_n+1;native_legacy_copy_last=ticks;native_legacy_copy_sum=native_legacy_copy_sum+ticks;
    if(ticks>native_legacy_copy_max)native_legacy_copy_max=ticks;
}
__attribute__((noinline)) void native_legacy_transfer_observed(IOReturn status,const void *request,uint64_t bytes) {
    native_legacy_transfer_calls=native_legacy_transfer_calls+1;
    native_legacy_xfer_seconds=native_legacy_seconds_now();
    // A frame reached the scanout, so the render server owns the panel: park the kernel text output so it
    // stops painting over it. Every panic path unparks it before printing.
    if(status==kIOReturnSuccess && !native_legacy_console_quiet) {
        unsigned wanted=1;PE_parse_boot_argn("offline-legacy-console-quiet",&wanted,sizeof(wanted));
        if(wanted && &vc_set_text_quiet) {vc_set_text_quiet(1);native_legacy_console_quiet=1;}
    }
    native_legacy_transfer_status=status;native_legacy_transfer_request=(uintptr_t)request;native_legacy_transfer_bytes=bytes;
    if(status!=kIOReturnSuccess && boot_progress_stage) {
        char message[120];snprintf(message,sizeof(message),"DISPLAY COPY FAILED status=%08x prepare=%u tries=%u",
          (unsigned)status,native_legacy_prepare_reason,native_legacy_prepare_attempts);
        boot_progress_stage(message);
    }
}
__attribute__((noinline)) void native_legacy_retirement_observed(IOService *display) {
    const unsigned char *bytes=reinterpret_cast<const unsigned char *>(display);
    uint64_t current=0,pending=0;uint32_t completed=0,presented=0,frames=0;
    memcpy(&current,bytes+5472,8);memcpy(&pending,bytes+5480,8);
    memcpy(&completed,bytes+5820,4);memcpy(&presented,bytes+5824,4);memcpy(&frames,bytes+252,4);
    native_legacy_retired_current=current;native_legacy_retired_pending=pending;
    native_legacy_retired_generation=completed;native_legacy_presented_generation=presented;native_legacy_retired_frames=frames;
    native_legacy_retirement_calls=native_legacy_retirement_calls+1;
    native_legacy_retire_seconds=native_legacy_seconds_now();
}
// One line for the panic dump: how far the display path got and when it stopped.
extern "C" char *native_legacy_state_line(char *buf,unsigned cap) {
    snprintf(buf,cap,"DISP map=%u cq=%u blk=%u val=%u acc=%u rej=%u xfer=%u ret=%u cl=%u stall=%u fail=%d last_val=%u last_xfer=%u last_ret=%u\n",
        (unsigned)native_legacy_scanout_wcomb,(unsigned)native_legacy_console_quiet,
        (unsigned)native_legacy_blank_frames,
        (unsigned)native_legacy_swap_validation_calls,(unsigned)native_legacy_swap_accepted_count,
        (unsigned)native_legacy_swap_rejected_count,(unsigned)native_legacy_transfer_calls,
        (unsigned)native_legacy_retirement_calls,(unsigned)native_legacy_client_calls,
        (unsigned)native_legacy_stall_recoveries,(int)native_legacy_transfer_status,
        (unsigned)native_legacy_validate_seconds,
        (unsigned)native_legacy_xfer_seconds,(unsigned)native_legacy_retire_seconds);
    return buf;
}
// Bring-up: the couple of counters the data probe's heartbeat needs, plus the same uptime clock the
// display rows use, so the two land on one timeline.
extern "C" void native_legacy_swap_counters(unsigned *swaps,unsigned *last_swap_seconds) {
    *swaps=(unsigned)native_legacy_swap_validation_calls;
    *last_swap_seconds=(unsigned)native_legacy_validate_seconds;
}
extern "C" unsigned native_legacy_uptime_seconds(void) {
    return (unsigned)native_legacy_seconds_now();
}
void native_legacy_registration_observed(IOService *display) {
    native_legacy_registration_calls=native_legacy_registration_calls+1;
    OSSerialize *xml=OSSerialize::withCapacity(2048);
    if(xml && display->serializeProperties(xml)) {
        unsigned size=xml->getLength();if(size>=sizeof(native_legacy_properties))size=sizeof(native_legacy_properties)-1;
        memcpy(native_legacy_properties,xml->text(),size);native_legacy_properties[size]=0;native_legacy_properties_length=size;
    }
    OSSafeReleaseNULL(xml);
}
void native_legacy_client_enter(task_t task,uint32_t type) {
    native_legacy_client_calls=native_legacy_client_calls+1;native_legacy_client_task=(uintptr_t)task;
    native_legacy_client_type=type;native_legacy_client_pid=task?proc_pid((proc_t)get_bsdtask_info(task)):0;
    unsigned clientPanic=0;
    PE_parse_boot_argn("offline-legacy-client-panic",&clientPanic,sizeof(clientPanic));
    if(clientPanic) {
        unsigned char *fb=reinterpret_cast<unsigned char *>((uintptr_t)native_legacy_object);
        void *surface=nullptr,*temp=nullptr;uint32_t sid=0;
        if(fb) {
            memcpy(&surface,fb+0x1618,sizeof(surface));
            memcpy(&temp,fb+0x1620,sizeof(temp));
            if(temp)memcpy(&sid,reinterpret_cast<unsigned char *>(temp)+0x10,sizeof(sid));
        }
        panic("UKE client: type=%u pid=%d task=%p surf=%p temp=%p sid=%u",
            (unsigned)type,(int)native_legacy_client_pid,task,surface,temp,(unsigned)sid);
    }
}
void native_legacy_client_observed(IOReturn status,IOUserClient *client) {
    native_legacy_client_status=status;native_legacy_client_object=(uintptr_t)client;
    if(client)strlcpy(native_legacy_client_class,client->getMetaClass()->getClassName(),sizeof(native_legacy_client_class));
    native_legacy_client_checkpoint();
}
__attribute__((noinline)) bool native_legacy_gop_mapping_observed(IOService *object,IOMemoryMap *mapping,uint32_t width,uint32_t height) {
    if((uintptr_t)object!=native_legacy_object)panic("NativeLegacyDisplay: wrong mapping owner");
    native_legacy_gop_map=(uintptr_t)mapping;native_legacy_gop_virtual=mapping->getVirtualAddress();
    native_legacy_gop_physical=mapping->getPhysicalAddress();native_legacy_gop_bytes=mapping->getLength();
    native_legacy_gop_width=width;native_legacy_gop_height=height;
    if(boot_progress_pulse_anchor && !diagnosticAnchorMapping) {
        PE_Video anchorVideo={};
        if(!PE_current_console(&anchorVideo) && anchorVideo.v_depth==32 &&
           anchorVideo.v_rowBytes<=65536 &&
           anchorVideo.v_width==width && anchorVideo.v_height==height &&
           anchorVideo.v_baseAddr==mapping->getPhysicalAddress() && !anchorVideo.v_rotate) {
            mapping->retain();
            if(boot_progress_pulse_anchor(mapping->getVirtualAddress(),mapping->getLength(),width,height,
                (unsigned)anchorVideo.v_rowBytes))diagnosticAnchorMapping=mapping;
            else mapping->release();
        }
    }
    native_legacy_gop_mapping_checkpoint();
    unsigned enabled=0;PE_parse_boot_argn("offline-legacy-unit-scale",&enabled,sizeof(enabled));
    if(!enabled)return true;
    native_legacy_unit_scale_calls=native_legacy_unit_scale_calls+1;native_legacy_unit_scale_status=1;
    unsigned phase=0;PE_parse_boot_argn("offline-legacy-phase",&phase,sizeof(phase));
    PE_Video video={};
    // The value is the UI scale: logical points = actual scanout pixels / scale (1..3). It changes
    // only the published display-scale; the scanout copy still moves one actual pixel per pixel.
    if(enabled<1 || enabled>3 || phase!=4 || unitScaleChosen || PE_current_console(&video) ||
       video.v_width!=width || video.v_height!=height || video.v_rotate ||
       mapping->getPhysicalAddress()!=video.v_baseAddr)return false;
    // Explicit offline UI policy: `enabled` actual GOP scanout pixels per logical
    // point in each direction (1 = native pixels). This is not physical pixel density,
    // panel timing, an Apple device identity or a synthesized mode list.
    unitScaleChosen=IORegistryEntry::fromPath("/chosen",gIODTPlane);
    if(!unitScaleChosen || !publishOrMatchWord(unitScaleChosen,"display-scale",enabled,unitScaleAdded) ||
       !publishOrMatchWord(unitScaleChosen,"display-rotation",video.v_rotate,unitRotationAdded)) {
        finishUnitScalePolicy(false);return false;
    }
    OSData *scale=OSDynamicCast(OSData,unitScaleChosen->getProperty("display-scale"));
    OSData *rotation=OSDynamicCast(OSData,unitScaleChosen->getProperty("display-rotation"));
    uint32_t actualScale=0,actualRotation=0;
    if(!scale || !rotation || scale->getLength()!=4 || rotation->getLength()!=4) {
        finishUnitScalePolicy(false);return false;
    }
    memcpy(&actualScale,scale->getBytesNoCopy(),4);memcpy(&actualRotation,rotation->getBytesNoCopy(),4);
    native_legacy_chosen_scale=actualScale;native_legacy_chosen_rotation=actualRotation;
    native_legacy_unit_scale_status=actualScale==enabled && actualRotation==video.v_rotate?0:2;
    if(native_legacy_unit_scale_status){finishUnitScalePolicy(false);return false;}
    return true;
}
__attribute__((noreturn,noinline)) void native_legacy_backend_guard(unsigned slot,void *object,void *caller) {
    native_legacy_guard_slot=slot;native_legacy_guard_object=(uintptr_t)object;native_legacy_guard_caller=(uintptr_t)caller;
    panic("NativeLegacyDisplay: leaf=%u caller=%llx stage=%u PM=%u swap=%u/%u copy=%08x bytes=%llu retire=%u handoff=%u/%u",
      slot,(uint64_t)(uintptr_t)caller,native_legacy_stage,native_legacy_pm_stage,
      native_legacy_swap_validation_result,native_legacy_swap_validation_reason,
      (unsigned)native_legacy_transfer_status,native_legacy_transfer_bytes,native_legacy_retirement_calls,
      native_legacy_prepare_reason,native_legacy_prepare_attempts);
}
void native_legacy_display_probe(void);
void native_legacy_display_probe(void) {
    // The registration path and optional original-userclient inspection both
    // reach this boot-thread entry. Run class constructors only once; a second
    // postModLoad would attempt to register the same metaclasses again.
    if(native_legacy_stage)return;
    native_legacy_stage=1;void *handle=OSMetaClass::preModLoad(g_kernel_kmod_info.name);
    if(!handle){native_legacy_display_checkpoint();return;}
    native_legacy_display_static_init();native_gop_presenter_static_init();native_legacy_meta_status=OSMetaClass::postModLoad(handle);
    if(native_legacy_meta_status){native_legacy_display_checkpoint();return;}
    PE_Video video={};native_legacy_stage=2;
    if(PE_current_console(&video) || !video.v_baseAddr || !video.v_width || !video.v_height || video.v_depth!=32
        || video.v_rotate || video.v_width>16384 || video.v_height>16384 || video.v_rowBytes<video.v_width*4
        || video.v_rowBytes>UINT64_MAX/video.v_height){native_legacy_display_checkpoint();return;}
    IOService *display=native_legacy_display_allocate();native_legacy_object=(uintptr_t)display;
    if(!display){native_legacy_display_checkpoint();return;}
    native_legacy_object_size=display->getMetaClass()->getClassSize();
    native_legacy_parent_match=(display->metaCast("IOMobileFramebufferLegacy") && display->metaCast("IOMobileFramebuffer") && display->metaCast("IOService"));
    native_legacy_stage=3;native_legacy_init_result=display->init();
    unsigned phase=1;PE_parse_boot_argn("offline-legacy-phase",&phase,sizeof(phase));
    if(native_legacy_init_result && (phase==2 || phase==3 || phase==4)) {
        // IOSurface matches the real IOBSD resource, published by bsd_autoconf.
        // Retain this actual object until that normal lifecycle boundary.
        pendingLegacyDisplay=display;return;
    }
    native_legacy_stage=7;display->release();native_legacy_released=1;native_legacy_stage=8;
    native_legacy_display_checkpoint();
}
// Default framebuffer surface bring-up. The original Legacy class reads the
// platform enable byte at +0x1780 and, when set, creates a temporary surface
// at +0x1620 in slot 299. Only the absent platform driver ever installs the
// default surface at +0x1618, so adopt the created surface there and let the
// original slot 174/242 produce the IOSurfaceID and Mach port name.
static void native_legacy_default_surface_state(IOService *display,bool adopt) {
    unsigned char *fb=reinterpret_cast<unsigned char *>(display);
    if(!fb)return;
    void *root=nullptr,*gate=nullptr,*workloop=nullptr,*surface=nullptr,*temp=nullptr,*region=nullptr;
    memcpy(&root,fb+0x1600,sizeof(root));
    memcpy(&gate,fb+0x1608,sizeof(gate));
    memcpy(&workloop,fb+0x1610,sizeof(workloop));
    memcpy(&surface,fb+0x1618,sizeof(surface));
    memcpy(&temp,fb+0x1620,sizeof(temp));
    memcpy(&region,fb+0x17c0,sizeof(region));
    uint32_t flag=fb[0x1780],width=0,height=0,format=0,planes=0,bpp=0,sid=0;
    memcpy(&width,fb+0x16b0,sizeof(width));
    memcpy(&height,fb+0x16b4,sizeof(height));
    memcpy(&format,fb+0x1700,sizeof(format));
    memcpy(&planes,fb+0x1704,sizeof(planes));
    memcpy(&bpp,fb+0x1708,sizeof(bpp));
    void *tempRegion=nullptr,*tempDescriptor=nullptr;
    if(temp) {
        memcpy(&sid,reinterpret_cast<unsigned char *>(temp)+0x10,sizeof(sid));
        memcpy(&tempRegion,reinterpret_cast<unsigned char *>(temp)+0x28,sizeof(tempRegion));
        memcpy(&tempDescriptor,reinterpret_cast<unsigned char *>(temp)+0x30,sizeof(tempDescriptor));
    }
    IOLog("BRAVEARK: display surface root=%p gate=%p wl=%p surface=%p temp=%p region=%p flag=%u dims=%ux%u mode=%08x/%u/%u sid=%u mem=%p desc=%p debugger=%u\n",
        root,gate,workloop,surface,temp,region,(unsigned)flag,(unsigned)width,(unsigned)height,
        (unsigned)format,(unsigned)planes,(unsigned)bpp,(unsigned)sid,tempRegion,tempDescriptor,
        (unsigned)PE_i_can_has_debugger(NULL));
    if(adopt && !surface && temp) {
        ((OSObject *)temp)->retain();
        memcpy(fb+0x1618,&temp,sizeof(temp));
        IOLog("BRAVEARK: display surface adopted surface=%p sid=%u\n",temp,(unsigned)sid);
    }
}
// Diagnostic parking point for the bring-up: print the original Legacy state
// on the panic screen so it survives the boot without a serial console.
static void native_legacy_default_surface_panic(IOService *display,bool started) {
    unsigned char *fb=reinterpret_cast<unsigned char *>(display);
    if(!fb)panic("UKE display: no object");
    void *root=nullptr,*region=nullptr,*temp=nullptr,*surface=nullptr;
    uint32_t flag=0,width=0,height=0,format=0,planes=0,bpp=0,sid=0;
    memcpy(&root,fb+0x1600,sizeof(root));
    memcpy(&region,fb+0x17c0,sizeof(region));
    memcpy(&temp,fb+0x1620,sizeof(temp));
    memcpy(&surface,fb+0x1618,sizeof(surface));
    flag=fb[0x1780];
    memcpy(&width,fb+0x16b0,sizeof(width));
    memcpy(&height,fb+0x16b4,sizeof(height));
    memcpy(&format,fb+0x1700,sizeof(format));
    memcpy(&planes,fb+0x1704,sizeof(planes));
    memcpy(&bpp,fb+0x1708,sizeof(bpp));
    if(temp)memcpy(&sid,reinterpret_cast<unsigned char *>(temp)+0x10,sizeof(sid));
    panic("UKE display: st=%u root=%p reg=%p temp=%p surf=%p sid=%u flag=%u dims=%ux%u fmt=%x/%u/%u",
        (unsigned)started,root,region,temp,surface,(unsigned)sid,(unsigned)flag,
        (unsigned)width,(unsigned)height,(unsigned)format,(unsigned)planes,(unsigned)bpp);
}
void native_legacy_display_late_probe(void);
extern void native_hid_input_probe(void);
extern void native_keystore_probe(void);
extern void native_touch_probe(void);
// Physical buttons (package/ButtonProbePeridot.cpp): power/resin on the PMK8550 PON and volume-up on the
// PMXR2230 GPIO expander, reported as HID Consumer bits through the sink NativeHidInput registered above.
extern void peridot_buttons_probe(void);
// The touch driver (drivers/ShengNovatekTouch): an IOService that owns the panel, brought up here because
// this is where the boot is settled enough for the SPI/DMA bring-up. Weak, so a build without it still links.
extern void native_novatek_touch_start(void) __attribute__((weak_import));
// Live-Data probe (package/PeridotDataProbe.c): peridot-data-probe=<n> lists what the running system actually
// sees under /private/var (keybags, migration/Setup prefs) - the overlay is invisible from the host.
extern void peridot_data_probe_start(void) __attribute__((weak_import));
extern void peridot_dump_start_late(void) __attribute__((weak_import));
extern void peridot_usb_debug_start(void) __attribute__((weak_import));
extern void boot_log_tick(unsigned) __attribute__((weak_import));
extern void native_touch_peridot_start(void) __attribute__((weak_import));
extern void sheng_cpufreq_probe(void);
extern void sheng_gpu_power_probe(void);
// peridot's own gated GPUCC/GCC/SMMU observation (package/PeridotGpuPowerProbe.cpp, peridot-gpu-power=<n>).
// Weak, so a build that does not compile that file still links.
extern void peridot_gpu_power_probe(void) __attribute__((weak_import));
// The thermal survey (package/PeridotThermalProbe.c, peridot-thermal=<n>): read-only TSENS survey. It runs
// after the GPU probe so a probe image shows both, and is inert without the boot argument.
extern void peridot_thermal_probe(void) __attribute__((weak_import));
void native_legacy_display_late_probe(void) {
    unsigned defaultSurface=0,defaultProbe=0,defaultPanic=0;
    PE_parse_boot_argn("offline-legacy-default-surface",&defaultSurface,sizeof(defaultSurface));
    PE_parse_boot_argn("offline-legacy-default-probe",&defaultProbe,sizeof(defaultProbe));
    PE_parse_boot_argn("offline-legacy-default-panic",&defaultPanic,sizeof(defaultPanic));
    native_keystore_probe();
    sheng_cpufreq_probe();
    sheng_gpu_power_probe();
    if (&peridot_gpu_power_probe) peridot_gpu_power_probe();
    if (&peridot_thermal_probe) peridot_thermal_probe();
    native_touch_probe();
    if (&native_novatek_touch_start) native_novatek_touch_start();
    if (&peridot_data_probe_start) peridot_data_probe_start();
    /* 2026-10-28: the msgbuf dump has to take the panel BEFORE the graphics client switches the display
     * mode. After that switch the kernel text console is drawn rotated 90 degrees and much smaller, so a
     * dump photographed then is an unreadable wall of vertical columns (logs/2026-10-28-18-11-01-730.jpg).
     * Starting the peridot-dump-at timer here instead of in load_init_program moves the freeze to ~t+20 s,
     * well before backboardd presents its first frame. The system keeps booting headless. */
    if (&peridot_dump_start_late) peridot_dump_start_late();
    native_hid_input_probe();
    peridot_buttons_probe();
    /* USB debug console: after the HID service exists (it registers the button sink) and before the
     * graphics client starts, so a serial capture sees the whole user-space boot. */
    if (&peridot_usb_debug_start) peridot_usb_debug_start();
    /* UFS diagnostic log (kits/peridot/BootLog.c, sheng-log=1): the writer waits for NativeUfs to publish the root
     * layout, so starting it here only arms it. This is the official log path: the window is readable afterwards
     * from stock recovery with dd + scripts/read-sheng-log.py --decode. */
    if (&boot_log_tick) boot_log_tick(0);
    IOService *display=pendingLegacyDisplay;if(!display)return;pendingLegacyDisplay=nullptr;
    native_legacy_surface_status=OSKextLoadKextWithIdentifier("com.apple.iokit.IOSurface");
    OSDictionary *matching=IOService::nameMatching("IOCoreSurfaceRoot");
    IOService *surface=matching?IOService::waitForMatchingService(matching,5000000000ULL):nullptr;
    native_legacy_surface_found=surface!=nullptr;OSSafeReleaseNULL(surface);OSSafeReleaseNULL(matching);
    PE_Video video={};
    if(!native_legacy_surface_status && native_legacy_surface_found && !PE_current_console(&video)
        && video.v_baseAddr && video.v_width && video.v_height && video.v_depth==32
        && !video.v_rotate && video.v_width<=16384 && video.v_height<=16384
        && video.v_rowBytes>=video.v_width*4 && video.v_rowBytes<=UINT64_MAX/video.v_height) {
        native_legacy_video_base=video.v_baseAddr;native_legacy_video_bytes=video.v_rowBytes*video.v_height;
        // A real firmware framebuffer resource, with addresses and extent
        // obtained from the actual GOP handoff. It has no invented compatible,
        // display list, panel timing, GPU/fence completion or vendor registers.
        native_legacy_stage=4;IOPlatformDevice *nub=new IOPlatformDevice;
        native_legacy_nub=(uintptr_t)nub;bool nubAttached=false,nubStarted=false,attached=false,started=false;
        IORegistryEntry *displayTreeParent=nullptr;bool dtAttached=false;
        IOService *parent=IOService::getResourceService();
        IODeviceMemory *memory=IODeviceMemory::withRange(video.v_baseAddr,video.v_rowBytes*video.v_height);
        OSArray *ranges=OSArray::withCapacity(1);
        if(nub && memory && ranges && parent && nub->init()) {
            ranges->setObject(memory);nub->setDeviceMemory(ranges);nub->setName("NativeGOPFramebuffer");
            nubAttached=nub->attach(parent);if(nubAttached)nubStarted=nub->start(parent);
            if(nubStarted) {
                unsigned phase=0;PE_parse_boot_argn("offline-legacy-phase",&phase,sizeof(phase));
                if(phase==4) {
                    // This is the actually implemented GOP display subsystem,
                    // attached to its real IOPlatformDevice memory resource.
                    // No Apple/vendor compatible or panel timing is supplied.
                    displayTreeParent=IORegistryEntry::fromPath("/arm-io",gIODTPlane);
                    const char type[]="display-subsystem";OSData *data=OSData::withBytes(type,sizeof(type));
                    if(displayTreeParent && data && nub->setProperty("device_type",data)) {
                        nub->setName("gop-display",gIODTPlane);dtAttached=nub->attachToParent(displayTreeParent,gIODTPlane);
                    }
                    OSSafeReleaseNULL(data);native_legacy_dt_attached=dtAttached;
                }
                if(phase==3) {
                    IOService *presenter=native_gop_presenter_create();bool presenterAttached=false;
                    if(presenter && presenter->init() && (presenterAttached=presenter->attach(nub)) && presenter->start(nub)) {
                        // Explicit own transport service only. The incomplete
                        // original framebuffer backend is never published.
                        activeGOPPresenter=presenter;activeGOPNub=nub;nub=nullptr;nubAttached=false;nubStarted=false;
                    } else {if(presenterAttached)presenter->detach(nub);OSSafeReleaseNULL(presenter);}
                } else {
                    SInt32 score=0;native_legacy_probe_match=(phase!=4 || dtAttached) && display->probe(nub,&score)==display;
                    if(native_legacy_probe_match)attached=display->attach(nub);
                    if(attached){
                        if(defaultSurface) {
                            unsigned char *fb=reinterpret_cast<unsigned char *>(display);
                            // The original create_default_fb_surface asks the
                            // IOSurfaceRoot for PurpleGfxMem, which only the absent
                            // platform/GPU driver provides. Without it the surface's
                            // +0x28 stays null and layout_buffers faults at
                            // 0xfffffff00578d110. Seed the original region cache at
                            // +0x17c0 with a plain system-memory descriptor; the
                            // 0x80-aligned rows need about 27.6 MB.
                            IOBufferMemoryDescriptor *region=
                                IOBufferMemoryDescriptor::withCapacity(0x2000000,kIODirectionOutIn);
                            uint32_t format=0x42475241,planes=1,bpp=4;
                            memset(fb+0x1700,0,0x70);
                            memcpy(fb+0x1700,&format,sizeof(format));
                            memcpy(fb+0x1704,&planes,sizeof(planes));
                            memcpy(fb+0x1708,&bpp,sizeof(bpp));
                            fb[0x1748]=0;
                            if(region) {
                                memcpy(fb+0x17c0,&region,sizeof(region));
                                fb[0x1780]|=1;
                                IOLog("BRAVEARK: default surface region=%p bytes=%llu\n",
                                    region,(unsigned long long)region->getLength());
                            } else {
                                IOLog("BRAVEARK: default surface region allocation failed; slot299 disabled\n");
                            }
                        }
                        native_legacy_stage=5;started=display->start(nub);native_legacy_start_result=started;
                    }
                    if(defaultPanic)native_legacy_default_surface_panic(display,started);
                    if(started && (defaultSurface || defaultProbe))native_legacy_default_surface_state(display,defaultSurface==1);
                    if(started && phase==4) {
                        activeLegacyDisplay=display;activeGOPNub=nub;native_legacy_stage=10;
                        finishUnitScalePolicy(true);
                        OSSafeReleaseNULL(displayTreeParent);
                        native_legacy_display_checkpoint();return;
                    }
                }
            }
        }
        native_legacy_stage=6;finishUnitScalePolicy(false);
        if(started)display->stop(nub);if(attached)display->detach(nub);
        if(dtAttached)nub->detachFromParent(displayTreeParent,gIODTPlane);
        if(nubStarted)nub->stop(parent);if(nubAttached)nub->detach(parent);
        OSSafeReleaseNULL(ranges);OSSafeReleaseNULL(memory);OSSafeReleaseNULL(nub);
        OSSafeReleaseNULL(displayTreeParent);
    }
    native_legacy_stage=7;display->release();native_legacy_released=1;native_legacy_stage=8;
    native_legacy_display_checkpoint();
}
}
