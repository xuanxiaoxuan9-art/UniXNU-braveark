/* SPDX-License-Identifier: BSD-2-Clause-Patent */
/* peridot's GMU stage-1 SMMU bring-up: the board half ShengGpuSmmu.c does not have.
 *
 * ShengGpuSmmuStart* owns one context bank's lifecycle (fault the stream, program the
 * disabled context, attach the stream, observe) but it deliberately does not allocate
 * tables, map memory or do a global SMMU reset. This unit supplies exactly that much:
 *
 *   1. validate the five GMU extents against ShengGmu.c's own sizes and fixed IOVAs;
 *   2. prepare a native4K table pool as an ArmSmmu4KLiveArena (all intermediate tables,
 *      no leaves) and publish it;
 *   3. ShengGpuSmmuStartLive(..., ShengGpuSmmuGmu, bank>=2, slot of stream 5, ...);
 *   4. map the five extents with ArmSmmu4KLiveUpdate, growing the already-mapped set;
 *   5. observe context+streams+the mapped extents again.
 *
 * The hardware facts this depends on (fixed IOVAs, sizes, "the GPU owns banks 0 and 1,
 * so the GMU needs bank >= 2") are the vendor driver's, not guesses:
 *   fw/android-harvest/msm-drv/a6xx_gmu.c  a6xx_gmu_memory_probe(): icache SZ_16M-SZ_16K
 *       @0x04000, dummy SZ_16K @0x60000000, debug SZ_4K*7 @0x60400000, log/hfi SZ_16K
 *       anywhere in [0x60001000, 0x80000000);
 *   fw/android-harvest/vendor-source/arm-smmu-qcom.c  GPU takes context banks 0 and 1.
 *
 * Nothing here touches power, clocks, the GPU SMMU's global registers or the GMU itself:
 * CX power, the GPUCC clock tree and the SMMU vote clock are the caller's prerequisites
 * (PeridotGpuPowerBoard.h modes 5/6), and the global SMMU enable is the probe's
 * mgb_smmu_global_ready() step. Masters must be quiesced: on this path the GMU is still
 * held in reset. Resources are retained on every outcome, including success. */
#ifndef PERIDOT_GMU_SMMU_H
#define PERIDOT_GMU_SMMU_H
#include <stddef.h>
#include <stdint.h>
#include "ArmSmmu4K.h"
#include "ArmSmmu4KLive.h"
#include "ShengGpuSmmu.h"
#include "ShengGpuSmmuSource.h"

#ifdef __cplusplus
extern "C" {
#endif

enum {
    PERIDOT_GMU_ICACHE = 0, PERIDOT_GMU_DUMMY, PERIDOT_GMU_DEBUG, PERIDOT_GMU_LOG, PERIDOT_GMU_HFI,
    PERIDOT_GMU_EXTENTS
};

/* Fixed IOVAs. The first three are the ones ShengGmu.c validates; log/hfi are the
 * vendor's dynamic range [0x60001000,0x80000000), placed right after dummy. */
#define PERIDOT_GMU_ICACHE_IOVA UINT64_C(0x00004000)
#define PERIDOT_GMU_DUMMY_IOVA  UINT64_C(0x60000000)
#define PERIDOT_GMU_LOG_IOVA    UINT64_C(0x60004000)
#define PERIDOT_GMU_HFI_IOVA    UINT64_C(0x60008000)
#define PERIDOT_GMU_DEBUG_IOVA  UINT64_C(0x60400000)

/* Sizes ShengGmu.c requires byte for byte (0xffc000/0x4000/0x7000/0x4000/0x4000). */
#define PERIDOT_GMU_ICACHE_BYTES 0x00ffc000u
#define PERIDOT_GMU_DUMMY_BYTES  0x00004000u
#define PERIDOT_GMU_DEBUG_BYTES  0x00007000u
#define PERIDOT_GMU_LOG_BYTES    0x00004000u
#define PERIDOT_GMU_HFI_BYTES    0x00004000u

/* The ID view this QSMMU v500 must present to ArmSmmu4K (see PeridotGmuSmmu.c):
 * 10-bit stream IDs (the DT's qcom,stream-id-range is 0x00..0x400), stage-1 AArch64,
 * 32 context-bank pages (context bank 0 at 0x20000), 4 KiB tables, 40-bit VA and PA.
 * The probe prints the raw register values unchanged. */
#define PERIDOT_GMU_ID0_VIEW   ((1u << 27) | (1u << 30) | (10u << 9))
#define PERIDOT_GMU_ID1_PAGES  (4u << 28)
#define PERIDOT_GMU_ID1_PAGE_MASK (7u << 28)
#define PERIDOT_GMU_ID2_VIEW   ((1u << 12) | (2u << 8) | (2u << 4))

/* 32-bit input addresses (the GMU's view) and 40-bit output addresses (this board's
 * RAM), matching the vendor's gmu_vm size of 0x80000000. */
#define PERIDOT_GMU_INPUT_BITS  32u
#define PERIDOT_GMU_OUTPUT_BITS 40u

typedef struct {
    void *cpu;              /* writable CPU mapping of the whole pool, page aligned */
    uint64_t physical;      /* contiguous physical base, page aligned */
    size_t capacity_pages;  /* pages owned by the caller */
} PeridotGmuSmmuPool;

typedef struct {
    void *cpu;              /* CPU mapping of the extent, page aligned */
    uint64_t physical;      /* contiguous physical base, page aligned */
    uint64_t iova;
    size_t bytes;
} PeridotGmuSmmuExtent;

typedef struct {
    PeridotGmuSmmuPool pool;
    PeridotGmuSmmuExtent extents[PERIDOT_GMU_EXTENTS];   /* canonical order, see the enum */
    unsigned bank;          /* >= SHENG_GPU_SMMU_GMU_BANK_MIN */
    unsigned slot;          /* SMR slot leased by the caller for stream 5 */
    unsigned poll_budget;   /* 1..1048576 */
} PeridotGmuSmmuPlan;

/* Cache publication. Must clean the range to the point of coherency (device walks read
 * the tables and the GMU reads the staged firmware) and return 0 only afterwards. A
 * barrier is not a cache clean, so this cannot be folded into ArmSmmu4KIo.barrier. */
typedef struct {
    void *cookie;
    int (*publish)(void *cookie, uint64_t physical, size_t bytes);
} PeridotGmuSmmuCache;

typedef enum {
    PeridotGmuSmmuDone = 0,
    PeridotGmuSmmuArgument,        /* the plan is unusable; nothing was written */
    PeridotGmuSmmuPrepareFailed,
    PeridotGmuSmmuPublishFailed,
    PeridotGmuSmmuStartFailed,
    PeridotGmuSmmuMapFailed,
    PeridotGmuSmmuObserveFailed
} PeridotGmuSmmuOutcome;

typedef struct {
    PeridotGmuSmmuOutcome outcome;
    unsigned phase;             /* 1 prepared, 2 published, 3 started, 4 mapped, 5 observed */
    ArmSmmu4KStatus prepare_status, start_status, map_status, observe_status;
    size_t capacity_pages, table_pages, leaf_pages;
    uint64_t arena_iova, arena_bytes, table_physical;
    uint64_t context_offset;
    uint32_t id0, id1, id2, scr0, global_fault;
    unsigned bank, slot, streams_bank, streams_count;
    unsigned start_phase, start_writes, start_poll_reads;
    unsigned map_published, map_descriptor_writes, mapped;
    unsigned extents;
} PeridotGmuSmmuSummary;

typedef struct {
    PeridotGmuSmmuPlan plan;           /* a copy: callers may free their own */
    /* ArmSmmu4K asks for table pages one at a time; these serve them out of plan.pool. */
    ArmSmmu4KTablePages pages;
    unsigned pages_taken;
    ArmSmmu4KLiveArena arena;
    ArmSmmu4KLiveState state;
    ArmSmmu4KContextConfig context;
    ArmSmmu4KRange ranges[PERIDOT_GMU_EXTENTS];
    ArmSmmu4KLiveVisibility visibility;
    ShengGpuSmmuSession session;
    ShengGpuSmmuResult started, observed;
    ArmSmmu4KLiveResult mapping;
    uint32_t alias_scratch[PERIDOT_GMU_EXTENTS];
    int (*publish)(void *, uint64_t, size_t);
    void *publish_cookie;
    PeridotGmuSmmuSummary summary;
} PeridotGmuSmmu;

/* Run the whole lifecycle. On failure every resource stays owned and the context bank
 * is not disabled (ShengGpuSmmu's contract); the caller must treat the SMMU as live. */
PeridotGmuSmmuOutcome PeridotGmuSmmuRun(const ArmSmmu4KIo *io, const PeridotGmuSmmuPlan *plan,
    const PeridotGmuSmmuCache *cache, PeridotGmuSmmu *state);

/* The pool the plan needs for these five extents: one root, the intermediate levels for
 * the whole [icache,debug] aperture and one level-3 table per 2 MiB the extents touch. */
size_t PeridotGmuSmmuTablePages(const PeridotGmuSmmuPlan *plan);

/* Range descriptors exactly as they are programmed, for host tests and the report. */
size_t PeridotGmuSmmuRanges(const PeridotGmuSmmuPlan *plan, ArmSmmu4KRange *out, size_t capacity);

const char *PeridotGmuSmmuOutcomeText(PeridotGmuSmmuOutcome outcome);

#ifdef __cplusplus
}
#endif
#endif
