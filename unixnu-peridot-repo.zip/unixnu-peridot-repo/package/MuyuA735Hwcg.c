// SPDX-License-Identifier: BSD-2-Clause-Patent
#include "PeridotA735Hwcg.h"

int PeridotA735ApplyHwcg(PeridotA735Write32 write32, void *cookie, unsigned *failed_at) {
    if (failed_at) *failed_at = 0xffffffffu;
    if (!write32) return -1;
    for (unsigned i = 0; i < PERIDOT_A735_HWCG_COUNT; ++i) {
        if (write32(cookie, PeridotA735Hwcg[i][0], PeridotA735Hwcg[i][1])) {
            if (failed_at) *failed_at = i;
            return -1;
        }
    }
    return (int)PERIDOT_A735_HWCG_COUNT;
}
