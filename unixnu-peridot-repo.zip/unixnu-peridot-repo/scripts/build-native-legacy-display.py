#!/usr/bin/env python3
"""Bind an owned concrete backend to the unchanged original Legacy lifecycle."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'build/native-legacy-display';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'kits/XnuPrelink'))
from native_prelink import macho,backed_offset,exports
def run(cmd,**kw):
    c=[str(x) for x in cmd]
    if c and 'clang' in c[0] and '-Wno-incompatible-sysroot' not in c:c.insert(1,'-Wno-incompatible-sysroot')
    return subprocess.check_output(c,timeout=90,**kw)
def require(v,why):
    if not v:raise SystemExit(why)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
print(run(['python3',ROOT/'scripts/audit-mobile-graphics-legacy.py'],text=True),end='')
audit=json.loads((ROOT/'build/display-analysis/mobile-graphics-legacy-abi.json').read_text())
print(run(['python3',ROOT/'scripts/audit-mobile-graphics-default-surface.py'],text=True),end='')
pure=audit['abstract_slots'];methods=audit['methods']
header='''// SPDX-License-Identifier: BSD-2-Clause-Patent
// Opaque ABI storage for the exact original class, not source-level access
// to its private fields. The actual original metadata supplies its full
// Framebuffer/Service/IOService ancestry. Only qualified base prototypes may
// be called from source; opaque entries are original dispatch targets only.
#pragma once
#include <IOKit/IOService.h>
#include <libkern/libkern.h>
struct OriginalLegacySwapRequest;
class IOMobileFramebufferLegacy : public IOService {
 OSDeclareAbstractStructors(IOMobileFramebufferLegacy)
 unsigned char originalPrivate[0x18a0-sizeof(IOService)];
public:
 // Both fields are qualified by the complete original slot-249 getter.
 // This modifies this object's own mode state, never a vtable or executable.
 void installBootDimensions(uint32_t width,uint32_t height) {
  *reinterpret_cast<uint32_t *>(reinterpret_cast<unsigned char *>(this)+5808)=width;
  *reinterpret_cast<uint32_t *>(reinterpret_cast<unsigned char *>(this)+5812)=height;
 }
 const OriginalLegacySwapRequest *pendingSwapRequest() const {
  const OriginalLegacySwapRequest *request=nullptr;
  memcpy(&request,reinterpret_cast<const unsigned char *>(this)+5480,sizeof(request));return request;
 }
 // The real normal scanout backend removes its pending head before calling
 // slot 295. Slot 312 is a discard path (terminal state 8), not presentation.
 // Limit this offline adapter to the observed single-entry queue and retain
 // exactly the original queue's reference for the original completion body.
 bool activateOnlyPendingSwap(const OriginalLegacySwapRequest *request) {
  auto self=reinterpret_cast<unsigned char *>(this);
  auto bytes=reinterpret_cast<const unsigned char *>(request);
  const void *current=nullptr,*head=nullptr,*tail=nullptr,*next=nullptr,*previous=nullptr;
  memcpy(&current,self+5472,8);memcpy(&head,self+5480,8);memcpy(&tail,self+5488,8);
  if(!request || current || head!=request)return false;
  memcpy(&next,bytes+2960,8);memcpy(&previous,bytes+2968,8);
  if(next || previous!=self+5480 || tail!=bytes+2960)return false;
  memcpy(self+5472,&request,8);
  const void *empty=nullptr,*emptyTail=self+5480;
  memcpy(self+5480,&empty,8);memcpy(self+5488,&emptyTail,8);return true;
 }
 void free() override;
 bool init(OSDictionary *properties=nullptr) override;
 IOReturn setProperties(OSObject *) override;
 void systemWillShutdown(IOOptionBits) override;
 IOService *probe(IOService *,SInt32 *) override;
 bool start(IOService *) override;
 void stop(IOService *) override;
 IOWorkLoop *getWorkLoop() const override;
 IOReturn newUserClient(task_t,void *,UInt32,IOUserClient **) override;
 IOReturn setPowerState(unsigned long,IOService *) override;
'''
for i in range(168,358):
    if i==184:header+=' virtual bool isMainDisplay();\n'
    elif i==188:header+=' virtual IOReturn getDotPitch(uint32_t *);\n'
    elif i==213:header+=' virtual IOReturn supportedFrameInfo(uint32_t,uint32_t *,char *,uint32_t *)=0;\n'
    elif i==242:header+=' virtual IOReturn copyDefaultSurfacePortName(task_t,uint32_t *);\n'
    elif i==249:header+=' virtual void getDisplayDimensions(uint32_t *,uint32_t *);\n'
    elif i==290:header+=' virtual void kickSwapQueue();\n'
    elif i==296:header+=' virtual bool validateSwap(const OriginalLegacySwapRequest *);\n'
    elif i==301:header+=' virtual bool getRefreshAttributes(uint64_t *,bool);\n'
    elif i==295:header+=' virtual void completeCurrentSwap();\n'
    elif i==337:header+=' virtual IOReturn collectCompletionReports(uint32_t,void *,uint32_t *,uint32_t)=0;\n'
    elif i==288:header+=' virtual bool startHardware();\n'
    elif i in pure:header+=f' virtual __attribute__((noreturn)) void opaque{i}()=0;\n'
    else:header+=f' virtual __attribute__((deprecated("Unclassified ABI: never call from source"))) void opaque{i}();\n'
header+='};\nstatic_assert(sizeof(IOMobileFramebufferLegacy)==0x18a0,"Actual original instance extent");\n'
(OUT/'OriginalLegacyFramebufferABI.h').write_text(header)
print(run(['python3',ROOT/'scripts/build-arm-driver.py','NativeLegacyDisplay'],text=True),end='')
obj=OUT/'NativeLegacyDisplay.o';raw=obj.read_bytes();image=macho(raw)
st=next(p for c,p,_ in image['commands'] if c==2);sy,count,strings,_=struct.unpack_from('<4I',raw,st+8);symbols=[]
for i in range(count):
    ix,kind,section,_,va=struct.unpack_from('<IBBHQ',raw,sy+i*16)
    symbols.append((raw[strings+ix:raw.index(b'\0',strings+ix)].decode(),va,kind))
vtable=next(va for name,va,_ in symbols if name=='__ZTV19NativeLegacyDisplay');relocations={}
for segment in image['segments']:
    for sec in segment['sections']:
        if sec['va']<=vtable<sec['va']+sec['size']:
            ro,rc=struct.unpack_from('<2I',raw,sec['command_offset']+56)
            for i in range(rc):
                offset,bits=struct.unpack_from('<2I',raw,ro+i*8)
                if bits>>27&1 and bits>>28==0 and bits>>25&3==3:relocations[sec['va']+offset]=symbols[bits&0xffffff][0]
compiled=[relocations.get(vtable+16+i*8) for i in range(358)]
require(all(compiled) and vtable+16+358*8 not in relocations,'Exact owned 358-entry vtable')
candidate=ROOT/'build/native-prelink/native-owner-mobile-graphics-candidate.macho'
if not candidate.exists():  # pruned: same fallback as scripts/audit-mobile-graphics-legacy.py (identical original family executable)
    later=sorted((ROOT/'build/native-prelink').glob('native-owner-ufs-cpu-desktop-*-candidate.macho'),key=lambda f:f.stat().st_mtime)
    require(later,'No reference candidate available');candidate=later[-1]
old=candidate.read_bytes();old_image=macho(old)
names={n:v for v,group in exports(old,old_image).items() for n in group}
def read(va,n):
    at=backed_offset(old_image['segments'],va,n,len(old));return old[at:at+n]
bindings={'__ZN25IOMobileFramebufferLegacyC2EPK11OSMetaClass':0xfffffff0057865cc,
          '__ZN25IOMobileFramebufferLegacyD2Ev':0xfffffff005786618,
          '__ZN25IOMobileFramebufferLegacy10gMetaClassE':0xfffffff006b35940,
          '__ZTV25IOMobileFramebufferLegacy':int(audit['legacy_vptr'],16)-16}
owned=[];native=[]
for i,name in enumerate(compiled):
    expected=int(methods[i]['address'],16)
    if name.startswith(('__ZN19NativeLegacyDisplay','__ZNK19NativeLegacyDisplay')):
        owned.append(i);require(i in (0,1,7,14,84,86,87,141,155,184,188,288,290,296,301) or i in pure,'Only qualified own methods and guarded leaves override')
    elif '25IOMobileFramebufferLegacy' in name:
        require(i not in pure,'No unresolved original abstract backend target');bindings[name]=expected
    else:
        # Inherited base symbols must exist in the original export table and sit inside the
        # inherited vtable prefix, but their absolute address is not a property this board can
        # pin: the alignment moved OSObject::release by 0x6b300 against the original cache, and a
        # base library routine is free to move as long as the override still finds its own code.
        require(i<168 and name in names,'Actual inherited native base symbol '+str(i));native.append(i)
require(owned==sorted([0,1,7,14,84,86,87,141,155,184,188,288,290,296,301]+pure),'Exact owned method set')
undefined={n for n,_,k in symbols if k==1 and 'IOMobileFramebufferLegacy' in n}
require(undefined==set(bindings),'All and only actual original-class imports qualified')
# The default-surface port fallback calls the original slot242 and the original
# surface -> Mach-port helper. They are not original-class imports, so bind
# their exact addresses after the class-import assertion.
bindings['_native_legacy_vsync_notify']=0xfffffff005796720
bindings['_native_legacy_set_refresh_properties']=0xfffffff00579ebb8
bindings['_uke_original_default_surface_port']=0xfffffff00578b390
bindings['_uke_surface_copy_port_name']=0xfffffff004baa90c
# Exact original IOSurface getters, independently observed through the real
# original swap request. These aliases call original code; no object layout
# is substituted and no original method/vtable is patched.
for name,address,field,wide in [
    ('descriptor',0xfffffff004b9ead0,48,True),('width',0xfffffff004b9ebbc,88,True),
    ('height',0xfffffff004b9ebc4,96,True),('stride',0xfffffff004b9ebd4,104,True),
    ('allocation',0xfffffff004b9ebfc,144,True),('format',0xfffffff004b9ebac,128,False),
    ('planes',0xfffffff004b9ebf4,152,False)]:
    expected=(0xf9400000 if wide else 0xb9400000)|((field//(8 if wide else 4))<<10)
    require(read(address,8)==struct.pack('<2I',expected,0xd65f03c0),'Exact original surface getter '+name)
    bindings['_native_legacy_surface_'+name]=address
# Both protected destructors/constructors must follow the exact original chain.
def branch(pc):
    word=struct.unpack('<I',read(pc,4))[0];require(word&0xfc000000==0x94000000,'Actual protected base call')
    value=word&0x3ffffff;return pc+4*(value-(1<<26) if value&(1<<25) else value)
require(branch(0xfffffff0057865fc)==0xfffffff00577b510 and branch(0xfffffff005786630)==0xfffffff00577b55c,
        'Original protected Legacy C2/D2 really call their original Service bases')
# Actual caller passes only self at slot 288 and tests bit zero of w0.
require(read(0xfffffff005787ef8,16)==bytes.fromhex('080040f9088144f900013fd6e0000037'),
        'Original bool start_hardware() call and result check')
getter=int(methods[249]['address'],16)
for offset,field in [(0x30,5808),(0x58,5812)]:
    require(struct.unpack('<I',read(getter+offset,4))[0]==0xb9400000|((field//4)<<10)|(8<<5)|8,
            'Actual original width/height getter fields')
require(int(methods[295]['address'],16)==0xfffffff005795b88 and
        read(0xfffffff005795b98,16)==bytes.fromhex('e00740f9280080520101001272d3ff97'),
        'Actual original slot-295 passes true to the normal current completion body')
require(read(0xfffffff00578aa7c,24)==bytes.fromhex('080040f9084545f9030080d2e20303aa0400805200013fd6'),
        'Original completion calls optional report slot 337 with null outputs and zero limit')
require(read(0xfffffff005777e9c,16)==bytes.fromhex('080040f908e142f900013fd6c0000036'),
        'Original isMainDisplay dispatch uses only self and tests boolean bit zero')
asm=OUT/'original-bindings.S';asm.write_text(''.join(f'.globl {name}\n.set {name}, {va:#x}\n' for name,va in sorted(bindings.items())))
sdk=run(['xcrun','--sdk','iphoneos','--show-sdk-path'],text=True).strip()
run(['xcrun','clang','-target','arm64-apple-ios17.0','-isysroot',sdk,'-c',asm,'-o',OUT/'original-bindings.o'])
llvm=Path(run(['brew','--prefix','llvm'],text=True).strip())/'bin';late=OUT/'NativeLegacyDisplay.late.o'
run([llvm/'llvm-objcopy','--remove-section=__DATA,__mod_init_func','--globalize-symbol=__GLOBAL__sub_I_NativeLegacyDisplay.cpp',obj,late])
def code(data,info):
    sec=next(s for g in info['segments'] for s in g['sections'] if s['name']=='__text');return data[sec['fileoff']:sec['fileoff']+sec['size']]
require(code(raw,image)==code(late.read_bytes(),macho(late.read_bytes())),'Only owned initializer section registration changes')
r=json.loads((ROOT/'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/iokit/DEVELOPMENT/IOPlatformExpert.cpo.json').read_text().strip().rstrip(','))
cmd=[];args=r['arguments'];i=0;source=ROOT/'kits/peridot/LegacyDisplayProbe.cpp'
while i<len(args):
    value=args[i]
    if value==r['file']:cmd.append(str(source))
    elif value=='-o':cmd+=['-o',str(OUT/'LegacyDisplayProbe.o')];i+=1
    elif value=='-Xclang' and args[i+1].startswith('-W'):i+=1
    elif not value.startswith('-W'):cmd.append(value)
    i+=1
cmd+=['-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unnecessary-virtual-specifier','-Wno-c99-designator','-Wno-reorder-init-list',
      '-Wno-deprecated-enum-enum-conversion','-I',str(ROOT/'.cache/xnu-work/osfmk')]
(ROOT/'kits/peridot-ci').mkdir(parents=True,exist_ok=True)
cmd+=['-I',str(ROOT/'kits/peridot-ci')]
run(cmd,cwd=r['directory'])
hid_source=ROOT/'kits/peridot/HidInputProbe.cpp'
hid_obj=OUT/'HidInputProbe.o'
hid_cmd=[str(hid_source) if str(arg)==str(source) else str(hid_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd]
run(hid_cmd,cwd=r['directory'])
keystore_source=ROOT/'kits/peridot/KeyStoreProbe.cpp'
keystore_obj=OUT/'KeyStoreProbe.o'
keystore_cmd=[str(keystore_source) if str(arg)==str(source) else str(keystore_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd]
run(keystore_cmd,cwd=r['directory'])
# Physical buttons (package/ButtonProbePeridot.cpp): power/resin on the PMK8550 PON and volume-up on the
# PMXR2230 GPIO expander, reported as HID Consumer bits. Compiled into this archive so it links with the
# probe entry point (LegacyDisplayProbe.cpp) that calls peridot_buttons_probe().
button_cpp=ROOT/'kits/peridot/ButtonProbePeridot.cpp';button_obj=OUT/'ButtonProbePeridot.o'
button_cmd=[str(button_cpp) if str(arg)==str(source) else str(button_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd]
run(button_cmd,cwd=r['directory'])
process_source=ROOT/'kits/peridot/BootProcessProbe.c'
process_obj=OUT/'BootProcessProbe.o'
pr=json.loads((ROOT/'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/osfmk/DEVELOPMENT/startup.o.json').read_text().strip().rstrip(','))
process_cmd=[];pa=pr['arguments'];j=0
while j<len(pa):
    value=pa[j]
    if value==pr['file']:process_cmd.append(str(process_source))
    elif value in ('-o','-MF','-MT','-MJ'):
        if value=='-o':process_cmd+=['-o',str(process_obj)]
        j+=1
    elif value=='-Xclang' and pa[j+1].startswith('-W'):j+=1
    elif not value.startswith('-W'):process_cmd.append(value)
    j+=1
process_cmd+=['-Wall','-Wextra','-Werror','-mgeneral-regs-only','-I',str(ROOT/'.cache/xnu-work/osfmk')]
run(process_cmd,cwd=pr['directory'])
trace_source=ROOT/'kits/peridot/BootUiTraceProbe.c'
trace_obj=OUT/'BootUiTraceProbe.o'
trace_cmd=[str(trace_source) if arg==str(process_source) else str(trace_obj) if arg==str(process_obj) else arg for arg in process_cmd]
run(trace_cmd,cwd=pr['directory'])
stub_source=ROOT/'kits/peridot/LegacyDisplayStubs.c'
stub_obj=OUT/'LegacyDisplayStubs.o'
run([str(stub_source) if arg==str(process_source) else str(stub_obj) if arg==str(process_obj) else arg for arg in process_cmd],cwd=pr['directory'])
# Default-off touch bring-up: C++ board probe plus the generic GENI SPI and Novatek protocol/touch libraries, compiled with the
# kernel C flags, and the firmware object generated from the copy kept outside Git.
touch_dir=OUT/'touch';touch_dir.mkdir(exist_ok=True)
touch_cpp=ROOT/'kits/peridot/TouchProbe.cpp';touch_cpp_obj=touch_dir/'TouchProbe.o'
peridot_touch_cpp=ROOT/'kits/peridot/TouchProbePeridot.cpp';peridot_touch_obj=touch_dir/'TouchProbePeridot.o'
# The production driver: ShengNovatekTouch (IOService). Same archive as the probe, because both need the
# GENI SPI and Novatek protocol objects; only the driver runs by default (peridot-touch-drv=1).
nvt_driver_cpp=ROOT/'drivers/ShengNovatekTouch/NativeNovatekTouch.cpp';nvt_driver_obj=touch_dir/'ShengNovatekTouch.o'
cpufreq_cpp=ROOT/'kits/peridot/CpuFreqProbe.cpp';cpufreq_obj=touch_dir/'CpuFreqProbe.o'
# uke first-console: NATIVE_ADRENO is off, so the sheng GpuPowerProbe's Adreno and
# GPU-addon imports would be undefined; omit it from this archive until the Adreno kit
# is linked. peridot's own probe (below) deliberately has no Adreno dependency.
run([str(touch_cpp) if str(arg)==str(source) else str(touch_cpp_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd],cwd=r['directory'])
run([str(cpufreq_cpp) if str(arg)==str(source) else str(cpufreq_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd],cwd=r['directory'])
run([str(peridot_touch_cpp) if str(arg)==str(source) else str(peridot_touch_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd],cwd=r['directory'])
# peridot's own gated GPUCC/GCC/SMMU observation (package/PeridotGpuPowerProbe.cpp): peridot-gpu-power=<n>. Unlike the
# sheng GpuPowerProbe below it has no Adreno imports, so it links without the Adreno kit; it only maps the
# windows and runs the host-tested sequence from PeridotGpuPowerBoard.h.
gpupower_cpp=ROOT/'kits/peridot/PeridotGpuPowerProbe.cpp';gpupower_obj=touch_dir/'PeridotGpuPowerProbe.o'
# GMU cold-start inputs for the probe: the generator emits the A735 image as a C object (from fw/), and
# AdrenoFirmware.c is the same planner ShengGmu.c uses. Both are C; the process_cmd template compiles C.
_W=ROOT.parents[3]
run([sys.executable,str(ROOT/'scripts/gen-peridot-gmu-source.py'),'--out',str(ROOT/'build/gpu'),
     '--dtb',str(_W/'fw/stock/dtb_3.dtb'),'--regs',str(_W/'fw/android-harvest/msm-regs'),
     '--driver',str(_W/'fw/android-harvest/msm-drv/a6xx_gmu.c'),
     '--firmware',str(_W/'fw/gpu-firmware/gen71100_gmu.bin')])
# The board OPP/BCM policy (ShengGmuVotesSource.h) and the AOP command-db reservation/version
# (ShengGmuCommandDbSource.h), both generated from this board's own DTB + the pinned A7xx catalog.
# ShengGmuVotes.c and ShengGmuCommandDb.c include these, so they must exist before they compile.
print(run([sys.executable,str(_W/'UniXNU-peridot/scripts/gen-peridot-gmu-votes.py'),
           '--out',str(ROOT/'build/gpu'),'--dtb',str(_W/'fw/stock/dtb_3.dtb'),
           '--catalog',str(_W/'fw/android-harvest/msm-drv/a7xx_catalog.c')],text=True),end='')
gmu_fw_c=ROOT/'build/gpu/PeridotGmuFirmware.c';gmu_fw_obj=touch_dir/'PeridotGmuFirmware.o'
adreno_fw_c=ROOT/'kits/AdrenoFirmware/AdrenoFirmware.c';adreno_fw_obj=touch_dir/'AdrenoFirmware.o'
for _src,_obj in ((gmu_fw_c,gmu_fw_obj),(adreno_fw_c,adreno_fw_obj)):
    run([str(_src) if arg==str(process_source) else str(_obj) if arg==str(process_obj) else arg for arg in process_cmd],
        cwd=pr['directory'])
# The probe includes AdrenoFirmware.h for the GMU planner, so it needs that kit's header directory.
# The GPU SMMU binding for peridot (base/size, GMU stream 5, "GPU owns banks 0 and 1 so the GMU
# needs bank >= 2"), generated from the same DTB and vendor arm-smmu-qcom.c as the GMU header.
print(run([sys.executable,str(_W/'UniXNU-peridot/scripts/gen-peridot-gpu-smmu-source.py'),
           '--out',str(ROOT/'build/gpu'),'--dtb',str(_W/'fw/stock/dtb_3.dtb'),
           '--vendor-source',str(_W/'fw/android-harvest/vendor-source')],text=True),end='')
# mode 9's board unit and the libraries it drives: ArmSmmu4K (native4K tables/context/streams),
# ShengGpuSmmu (the bank/stream lifecycle) and PeridotGmuSmmu (this board's plan). All plain C,
# compiled with the kernel's C recipe like PeridotDataProbe.c above.
smmu_dir=OUT/'gmu-smmu';smmu_dir.mkdir(exist_ok=True)
smmu_sources=[ROOT/'kits/ArmSmmu4K'/name for name in
              ('ArmSmmu4K.c','ArmSmmu4KContext.c','ArmSmmu4KProgram.c','ArmSmmu4KStreams.c',
               'ArmSmmu4KMmio.c','ArmSmmu4KAudit.c','ArmSmmu4KTableMemory.c','ArmSmmu4KLive.c')]
smmu_sources+=[ROOT/'kits/peridot/ShengGpuSmmu.c',ROOT/'kits/peridot/PeridotGmuSmmu.c']
smmu_include=['-I',str(ROOT/'kits/ArmSmmu4K'),'-I',str(ROOT/'build/gpu')]
smmu_objs=[]
for _src in smmu_sources:
    _obj=smmu_dir/(_src.stem+'.o');smmu_objs.append(_obj)
    run([str(_src) if str(arg)==str(process_source) else str(_obj) if str(arg)==str(process_obj) else arg for arg in process_cmd]+smmu_include,cwd=pr['directory'])
gmu_include=['-I',str(ROOT/'kits/AdrenoFirmware'),'-I',str(ROOT/'kits/ArmSmmu4K'),'-I',str(ROOT/'build/gpu')]
# mode 11's cold start: the shared ShengGmu.c lifecycle plus the board vote/command-db units and
# the HFI kit they call. Plain C, same kernel recipe as the units above.
cold_dir=OUT/'gmu-cold';cold_dir.mkdir(exist_ok=True)
cold_sources=[ROOT/'kits/peridot/ShengGmu.c',ROOT/'kits/peridot/ShengGmuVotes.c',
              ROOT/'kits/peridot/ShengGmuCommandDb.c',ROOT/'kits/peridot/PeridotRpmhRsc.c',
              ROOT/'kits/AdrenoFirmware/AdrenoHfi.c',
              ROOT/'kits/AdrenoFirmware/AdrenoHfiStartup.c',ROOT/'kits/AdrenoFirmware/AdrenoHfiVotes.c']
cold_objs=[]
for _src in cold_sources:
    _obj=cold_dir/(_src.stem+'.o');cold_objs.append(_obj)
    run([str(_src) if str(arg)==str(process_source) else str(_obj) if str(arg)==str(process_obj) else arg for arg in process_cmd]+gmu_include,cwd=pr['directory'])
run([str(gpupower_cpp) if str(arg)==str(source) else str(gpupower_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd]+gmu_include,cwd=r['directory'])
# The driver lives in drivers/ShengNovatekTouch but needs the GENI SPI library and the board headers;
# give it those two include directories explicitly instead of relative paths through symlinked trees.
nvt_include=['-I',str(ROOT/'drivers/QcomGeniSpi'),'-I',str(ROOT/'kits/peridot')]
# Live-Data probe (package/PeridotDataProbe.c): asks the kernel's VFS what /private/var really holds, which no
# host tool can see because the persistent overlay only exists on the tablet.
data_probe_src=ROOT/'kits/peridot/PeridotDataProbe.c';data_probe_obj=touch_dir/'PeridotDataProbe.o'
data_cmd=[str(arg) for arg in cmd]
for i,arg in enumerate(data_cmd):
    if arg==str(r['file'] if False else source): data_cmd[i]=str(data_probe_src)
    elif arg==str(OUT/'LegacyDisplayProbe.o'): data_cmd[i]=str(data_probe_obj)
data_cmd=[arg.replace('--driver-mode=g++','--driver-mode=gcc').replace('-xc++','-xc') for arg in data_cmd]
data_cmd=[arg for arg in data_cmd if arg not in ('-fapple-kext','-fc++-static-destructors=none','-fsized-deallocation','-std=gnu++2b')]
data_cmd+=['-std=gnu11']
run(data_cmd,cwd=r['directory'])
run([str(nvt_driver_cpp) if str(arg)==str(source) else str(nvt_driver_obj) if str(arg)==str(OUT/'LegacyDisplayProbe.o') else arg for arg in cmd]+nvt_include,cwd=r['directory'])
print(run(['python3',ROOT/'scripts/gen-touch-firmware.py'],text=True),end='')
touch_c=[ROOT/'drivers/QcomGeniSpi/GeniSpi.c',ROOT/'drivers/ShengNovatekTouch/NvtProtocol.c',
         ROOT/'drivers/ShengNovatekTouch/NvtTouchCore.c',ROOT/'build/native-touch/NvtFirmware.c']
touch_objs=[]
for src in touch_c:
    obj=touch_dir/(src.stem+'.o');touch_objs.append(obj)
    run([str(src) if arg==str(process_source) else str(obj) if arg==str(process_obj) else arg for arg in process_cmd],cwd=pr['directory'])
archive=OUT/'libNativeLegacyDisplay.late.a';archive.unlink(missing_ok=True)
print(run(['python3',ROOT/'scripts/build-native-hid-input.py'],text=True),end='')
hid_dir=ROOT/'build/native-hid-input'
print(run(['python3',ROOT/'scripts/build-arm-driver.py','AppleKeyStoreState'],text=True),end='')
keyevents=ROOT/'build/native-keystore-events'
keyevents_late=keyevents/'AppleKeyStoreState.late.o'
run([llvm/'llvm-objcopy','--remove-section=__DATA,__mod_init_func',
     '--globalize-symbol=__GLOBAL__sub_I_NativeKeyStoreEvents.cpp',
     keyevents/'AppleKeyStoreState.o',keyevents_late])
require(code((keyevents/'AppleKeyStoreState.o').read_bytes(),macho((keyevents/'AppleKeyStoreState.o').read_bytes()))==
        code(keyevents_late.read_bytes(),macho(keyevents_late.read_bytes())),'Owned event-service instructions unchanged by late init staging')
run(['xcrun','ar','rcs',archive,late,OUT/'original-bindings.o',OUT/'LegacyDisplayProbe.o',hid_obj,keystore_obj,process_obj,trace_obj,
     hid_dir/'NativeHidInput.late.o',hid_dir/'hid-original-bindings.o',keyevents_late,touch_cpp_obj,cpufreq_obj,peridot_touch_obj,gpupower_obj,gmu_fw_obj,adreno_fw_obj,nvt_driver_obj,data_probe_obj,button_obj,stub_obj,*touch_objs,*smmu_objs,*cold_objs])
sources=[ROOT/'drivers/GopFramebuffer/NativeLegacyDisplay.cpp',
         ROOT/'drivers/GopFramebuffer/NativeLegacyRequest.h',source,hid_source,keystore_source,process_source,trace_source,ROOT/'kits/peridot/BootUiTraceCore.h',ROOT/'kits/peridot/BootUiTraceDetails.h',
         ROOT/'drivers/ShengHidInput/NativeHidInput.cpp',ROOT/'scripts/build-native-hid-input.py',
         ROOT/'drivers/AppleKeyStoreState/NativeKeyStoreEvents.cpp',touch_cpp,cpufreq_cpp,peridot_touch_cpp,gpupower_cpp,ROOT/'kits/peridot/PeridotGpuPowerBoard.h',gmu_fw_c,adreno_fw_c,ROOT/'drivers/ShengNovatekTouch/NativeNovatekTouch.cpp',ROOT/'drivers/ShengNovatekTouch/NativeNovatekTouch.h',ROOT/'kits/peridot/TouchBoardPeridot.h',ROOT/'kits/peridot/TouchBoard.h',stub_source,
         ROOT/'drivers/QcomGeniSpi/GeniSpi.c',ROOT/'drivers/QcomGeniSpi/GeniSpi.h',ROOT/'drivers/ShengNovatekTouch/NvtProtocol.c',
         ROOT/'drivers/ShengNovatekTouch/NvtProtocol.h',ROOT/'drivers/ShengNovatekTouch/NvtTouchCore.c',ROOT/'drivers/ShengNovatekTouch/NvtTouchCore.h',
         ROOT/'kits/peridot/PeridotGmuSmmu.c',ROOT/'kits/peridot/PeridotGmuSmmu.h',ROOT/'kits/peridot/ShengGpuSmmu.c',ROOT/'kits/peridot/ShengGpuSmmu.h',*smmu_sources,
         *cold_sources,ROOT/'kits/peridot/ShengGmu.h',ROOT/'kits/peridot/ShengGmuVotes.h',ROOT/'kits/peridot/ShengGmuCommandDb.h',ROOT/'kits/peridot/PeridotRpmhRsc.h',
         ROOT/'kits/peridot/PeridotRpmhRscHostTests.c',
         ROOT/'build/gpu/ShengGmuVotesSource.h',ROOT/'build/gpu/ShengGmuCommandDbSource.h',
         ROOT/'kits/peridot/PeridotGmuVotesHostTests.c']
print(run(['python3',ROOT/'scripts/build-arm-driver.py','NativeGOPPresenter'],text=True),end='')
gop=ROOT/'build/native-gop-presenter';gop_late=gop/'NativeGOPPresenter.late.o'
run([llvm/'llvm-objcopy','--remove-section=__DATA,__mod_init_func','--globalize-symbol=__GLOBAL__sub_I_NativeGOPPresenter.cpp',
     gop/'NativeGOPPresenter.o',gop_late])
require(code((gop/'NativeGOPPresenter.o').read_bytes(),macho((gop/'NativeGOPPresenter.o').read_bytes()))==
        code(gop_late.read_bytes(),macho(gop_late.read_bytes())),'Owned presenter instructions unchanged by late init staging')
run(['xcrun','ar','rcs',archive,gop_late])
sources.extend([ROOT/'drivers/GopFramebuffer/NativeGOPPresenter.cpp',ROOT/'drivers/GopFramebuffer/NativeGOPWire.h'])
(OUT/'build-report.json').write_text(json.dumps(dict(
    source_sha256={str(p.relative_to(ROOT)):sha(p) for p in sources},generated_abi_sha256=sha(OUT/'OriginalLegacyFramebufferABI.h'),
    original_candidate_sha256=sha(candidate),original_audit_sha256=sha(ROOT/'build/display-analysis/mobile-graphics-legacy-abi.json'),
    compiled_object_sha256=sha(obj),late_object_sha256=sha(late),archive_sha256=sha(archive),
    bindings={n:hex(v) for n,v in bindings.items()},virtual_entries=358,owned_entries=owned,inherited_native_entries=native,
    guarded_backend_leaves=[i for i in pure if i not in (213,337)],original_instructions_modified=False,driver_initialized=False,display_presented=False,desktop=False),indent=2)+'\n')
print('Built genuine original Legacy inheritance/dispatch; seven backend leaves still guarded, runtime lifecycle unqualified')
