#!/usr/bin/env python3
"""Build the opt-in pram log writer against this source kernel's actual ABI."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'build/braveark-last-log'
OUT.mkdir(parents=True, exist_ok=True)
record = json.loads((ROOT / 'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/osfmk/DEVELOPMENT/startup.o.json').read_text().strip().rstrip(','))
source = ROOT / 'kits/peridot/BravearkLastLog.c'
obj = OUT / 'BravearkLastLog.o'
command = []
args = record['arguments']
i = 0
while i < len(args):
    arg = args[i]
    if arg == record['file']:
        command.append(str(source))
    elif arg in ('-o', '-MF', '-MT', '-MJ'):
        if arg == '-o':
            command += ['-o', str(obj)]
        i += 1
    elif arg == '-Xclang' and args[i + 1].startswith('-W'):
        i += 1
    elif not arg.startswith('-W'):
        command.append(arg)
    i += 1
# Xcode 27 treats the macOS SDK against an iOS target as an error (as in build-arm-driver.py).
command += ['-mgeneral-regs-only', '-Wall', '-Wextra', '-Werror', '-Wno-incompatible-sysroot']
subprocess.run(command, cwd=record['directory'], check=True, timeout=120)
(OUT / 'compile-command.json').write_text(json.dumps(command, indent=2) + '\n')

policy_record = json.loads((ROOT / 'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/bsd/DEVELOPMENT/kern_exec.o.json').read_text().strip().rstrip(','))
policy_source = ROOT / 'kits/peridot/BootWatchdogPolicy.c'
policy_obj = OUT / 'BootWatchdogPolicy.o'
policy_command = []
policy_args = policy_record['arguments']
j = 0
while j < len(policy_args):
    arg = policy_args[j]
    if arg == policy_record['file']:
        policy_command.append(str(policy_source))
    elif arg in ('-o', '-MF', '-MT', '-MJ'):
        if arg == '-o':
            policy_command += ['-o', str(policy_obj)]
        j += 1
    elif arg == '-Xclang' and policy_args[j + 1].startswith('-W'):
        j += 1
    elif not arg.startswith('-W'):
        policy_command.append(arg)
    j += 1
policy_command += ['-mgeneral-regs-only', '-Wall', '-Wextra', '-Werror', '-Wno-incompatible-sysroot']
subprocess.run(policy_command, cwd=policy_record['directory'], check=True, timeout=120)
(OUT / 'policy-compile-command.json').write_text(json.dumps(policy_command, indent=2) + '\n')

# BSD-side crash-log reader (kernel VFS): compiled with the kern_exec record like the policy.
crash_source = ROOT / 'kits/peridot/PeridotCrashLog.c'
crash_obj = OUT / 'PeridotCrashLog.o'
crash_command = [str(crash_source) if arg == str(policy_source) else str(crash_obj) if arg == str(policy_obj) else arg
                 for arg in policy_command]
subprocess.run(crash_command, cwd=policy_record['directory'], check=True, timeout=120)
(OUT / 'crash-compile-command.json').write_text(json.dumps(crash_command, indent=2) + '\n')

# UFS diagnostic log writer, ported from UniXNU-sheng. Same BSD header set as PeridotCrashLog.c.
bootlog_source = ROOT / 'kits/peridot/BootLog.c'
bootlog_obj = OUT / 'BootLog.o'
# It includes <kern/misc_protos.h>, which only the osfmk header set exposes, so it is compiled with the
# startup.o record (the same one that builds BravearkLastLog.o) rather than the BSD one.
bootlog_command = [str(bootlog_source) if arg == str(source) else str(bootlog_obj) if arg == str(obj) else arg
                   for arg in command]
subprocess.run(bootlog_command, cwd=record['directory'], check=True, timeout=120)
(OUT / 'bootlog-compile-command.json').write_text(json.dumps(bootlog_command, indent=2) + '\n')

# Weak definitions for the sheng-only helpers BootLog.c still names (a weak declaration does not link in a
# static Mach-O; a weak definition does, and a real board helper would still win).
stub_source = ROOT / 'kits/peridot/BootLogStubs.c'
stub_obj = OUT / 'BootLogStubs.o'
stub_command = [str(stub_source) if arg == str(source) else str(stub_obj) if arg == str(obj) else arg
                for arg in command]
subprocess.run(stub_command, cwd=record['directory'], check=True, timeout=120)

archive = OUT / 'libBravearkLastLog.a'
archive.unlink(missing_ok=True)
subprocess.run(['xcrun', 'ar', 'rcs', str(archive), str(obj), str(policy_obj), str(crash_obj), str(bootlog_obj),
                str(stub_obj)], check=True, timeout=30)
(OUT / 'build-report.json').write_text(json.dumps({
    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'object_sha256': hashlib.sha256(obj.read_bytes()).hexdigest(),
    'policy_source_sha256': hashlib.sha256(policy_source.read_bytes()).hexdigest(),
    'policy_object_sha256': hashlib.sha256(policy_obj.read_bytes()).hexdigest(),
    'crash_source_sha256': hashlib.sha256(crash_source.read_bytes()).hexdigest(),
    'crash_object_sha256': hashlib.sha256(crash_obj.read_bytes()).hexdigest(),
    'bootlog_source_sha256': hashlib.sha256(bootlog_source.read_bytes()).hexdigest(),
    'bootlog_object_sha256': hashlib.sha256(bootlog_obj.read_bytes()).hexdigest(),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'hardware_execution': False,
}, indent=2) + '\n')
print('PASS: strict source-kernel ARM64 pram writer and watchdog policy build')
